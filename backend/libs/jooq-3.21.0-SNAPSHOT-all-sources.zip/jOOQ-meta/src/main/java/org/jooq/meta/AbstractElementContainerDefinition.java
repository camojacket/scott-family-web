/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta;

import static java.util.Collections.singletonList;
import static org.jooq.meta.AbstractDatabase.fetchedSize;
import static org.jooq.meta.AbstractDatabase.getDefinition;
import static org.jooq.tools.StringUtils.defaultIfEmpty;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jooq.DataType;
import org.jooq.Pro;
import org.jooq.impl.ParserException;
import org.jooq.impl.SQLDataType;
import org.jooq.meta.jaxb.SyntheticColumnType;
import org.jooq.meta.jaxb.SyntheticReadonlyRowidType;
import org.jooq.tools.JooqLogger;
import org.jooq.tools.StringUtils;

/**
 * A base implementation for element container definitions
 *
 * @author Lukas Eder
 */
public abstract class AbstractElementContainerDefinition<E extends TypedElementDefinition<?>>
extends AbstractDefinition {

    /**
     * Precision and scale for those dialects that don't formally provide that
     * information in a separate field
     */
    protected static final Pattern  PRECISION_SCALE = Pattern.compile("\\((\\d+)\\s*(?:,\\s*(\\d+))?\\)");
    private static final JooqLogger log             = JooqLogger.getLogger(AbstractElementContainerDefinition.class);

    private List<E>                 elements;
    private List<E>                 elementsIncludingHidden;

    public AbstractElementContainerDefinition(SchemaDefinition schema, String name, String comment) {
        this(schema, null, name, comment);
    }

    public AbstractElementContainerDefinition(SchemaDefinition schema, PackageDefinition pkg, String name, String comment) {
        super(schema.getDatabase(), schema, pkg, name, comment, null, null);
    }

    public AbstractElementContainerDefinition(SchemaDefinition schema, PackageDefinition pkg, String name, String comment, String source) {
        super(schema.getDatabase(), schema, pkg, name, comment, null, source);
    }

    @SuppressWarnings("unchecked")
    protected final List<E> getElements() {
        if (elements == null) {
            elements = new ArrayList<>();
            elementsIncludingHidden = new ArrayList<>();

            try {
                AbstractDatabase db = (AbstractDatabase) getDatabase();
                List<E> e = getElements0();

                // [#5335] Warn if a table definition contains several identity columns
                if (this instanceof TableDefinition t) {
                    if (e.stream().map(c -> (ColumnDefinition) c).filter(ColumnDefinition::isIdentity).count() > 1)
                        Logging.log(getDatabase().onMetadataProblem(),
                            () -> "Table " + getOutputName() + " has multiple identity columns. Only the first one is considered.");


                    SyntheticReadonlyRowidType rowids = hasSyntheticReadonlyRowid(t);
                    if (rowids != null) {
                        (e = new ArrayList<>(e)).add(0, (E) new DefaultColumnDefinition(
                            (TableDefinition) this,
                            defaultIfEmpty(rowids.getName(), "ROWID"),
                            -1,
                            new DefaultDataTypeDefinition(db, getSchema(), "ROWID", 0, 0, 0, false, true, null, null, false, null, null, null, "org.jooq.RowId"),
                            false,
                            true,
                            "The ROWID"
                        ));
                    }

                    List<SyntheticColumnType> columns = hasSyntheticColumnTypes(t);
                    for (SyntheticColumnType c : columns) {
                        DataType<?> type = SQLDataType.OTHER;

                        try {
                            type = create().parser().parseField("null::" + c.getType()).getDataType();
                        }
                        catch (ParserException ignore) {}

                        (e = new ArrayList<>(e)).add((E) new DefaultColumnDefinition(
                            (TableDefinition) this,
                            c.getName(),
                            e.size(),
                            new DefaultDataTypeDefinition(
                                db,
                                getSchema(),
                                c.getType(),
                                type.hasLength() ? type.length() : null,
                                type.hasPrecision() ? type.precision() : null,
                                type.hasScale() ? type.scale() : null,
                                true,
                                (String) null
                            ),
                            false,
                            false,
                            c.getComment()
                        ).synthetic(true));
                    }


                }

                // [#2603] Filter exclude / include also for table columns
                if (this instanceof TableDefinition && db.getIncludeExcludeColumns()) {
                    elementsIncludingHidden = db.filterExcludeInclude(e);
                    log.info("Columns fetched", fetchedSize(e, elements));
                }
                else
                    elementsIncludingHidden = e;

                db.sort(elementsIncludingHidden);
                elements.addAll(elementsIncludingHidden);


                elements.removeIf(x -> x.getType().isHidden());

            }
            catch (Exception e) {
                log.error("Error while initialising type", e);
            }
        }

        return elements;
    }

    protected final List<E> getElementsIncludingHidden() {
        getElements();
        return elementsIncludingHidden;
    }



    @Pro
    private static SyntheticReadonlyRowidType hasSyntheticReadonlyRowid(TableDefinition table) {
        AbstractDatabase db = (AbstractDatabase) table.getDatabase();

        for (SyntheticReadonlyRowidType ro : db.getConfiguredSyntheticReadonlyRowids()) {
            for (TableDefinition t : db.filter(singletonList(table), ro.getTables())) {
                log.info("Synthetic readonly rowid", table.getQualifiedName());
                db.markUsed(ro);
                return ro;
            }
        }

        return null;
    }

    @Pro
    private static List<SyntheticColumnType> hasSyntheticColumnTypes(TableDefinition table) {
        List<SyntheticColumnType> result = new ArrayList<>();
        AbstractDatabase db = (AbstractDatabase) table.getDatabase();

        for (SyntheticColumnType c : db.getConfiguredSyntheticColumns()) {
            for (TableDefinition t : db.filter(singletonList(table), c.getTables())) {
                log.info("Synthetic column", table.getQualifiedName() + "." + c.getName());
                db.markUsed(c);
                result.add(c);
            }
        }

        return result;
    }



    protected final E getElement(String name) {
        return getElement(name, false);
    }

    protected final E getElement(String name, boolean ignoreCase) {
        return getDefinition(getElements(), name, ignoreCase);
    }

    protected final E getElement(int index) {
        return getElements().get(index);
    }

    protected abstract List<E> getElements0() throws SQLException;

    protected Number parsePrecision(String typeName) {
        if (typeName.contains("(")) {
            Matcher m = PRECISION_SCALE.matcher(typeName);

            if (m.find() && !StringUtils.isBlank(m.group(1)))
                return Integer.valueOf(m.group(1));
        }

        return 0;
    }

    protected Number parseScale(String typeName) {
        if (typeName.contains("(")) {
            Matcher m = PRECISION_SCALE.matcher(typeName);

            if (m.find() && !StringUtils.isBlank(m.group(2)))
                return Integer.valueOf(m.group(2));
        }

        return 0;
    }

    protected String parseTypeName(String typeName) {
        return typeName.replace(" NOT NULL", "");
    }

    protected boolean parseNotNull(String typeName) {
        return typeName.toUpperCase().contains("NOT NULL");
    }
}
