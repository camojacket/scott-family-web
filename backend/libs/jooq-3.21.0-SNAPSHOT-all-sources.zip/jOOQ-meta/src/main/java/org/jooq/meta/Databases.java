/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta;

import org.jooq.SQLDialect;
import org.jooq.meta.ase.ASEDatabase;
import org.jooq.meta.auroramysql.AuroraMySQLDatabase;
import org.jooq.meta.bigquery.BigQueryDatabase;
import org.jooq.meta.clickhouse.ClickHouseDatabase;
import org.jooq.meta.cockroachdb.CockroachDBDatabase;
import org.jooq.meta.cubrid.CUBRIDDatabase;
import org.jooq.meta.databricks.DatabricksDatabase;
import org.jooq.meta.db2.DB2Database;
import org.jooq.meta.derby.DerbyDatabase;
import org.jooq.meta.duckdb.DuckDBDatabase;
import org.jooq.meta.exasol.ExasolDatabase;
import org.jooq.meta.firebird.FirebirdDatabase;
import org.jooq.meta.h2.H2Database;
import org.jooq.meta.hana.HanaDatabase;
import org.jooq.meta.hsqldb.HSQLDBDatabase;
import org.jooq.meta.ignite.IgniteDatabase;
import org.jooq.meta.informix.InformixDatabase;
import org.jooq.meta.ingres.IngresDatabase;
import org.jooq.meta.jdbc.JDBCDatabase;
import org.jooq.meta.mariadb.MariaDBDatabase;
import org.jooq.meta.memsql.MemSQLDatabase;
import org.jooq.meta.mysql.MySQLDatabase;
import org.jooq.meta.oracle.OracleDatabase;
import org.jooq.meta.postgres.PostgresDatabase;
import org.jooq.meta.redshift.RedshiftDatabase;
import org.jooq.meta.snowflake.SnowflakeDatabase;
import org.jooq.meta.sqldatawarehouse.SQLDataWarehouseDatabase;
import org.jooq.meta.sqlite.SQLiteDatabase;
import org.jooq.meta.sqlserver.SQLServerDatabase;
import org.jooq.meta.sybase.SybaseDatabase;
import org.jooq.meta.teradata.TeradataDatabase;
import org.jooq.meta.trino.TrinoDatabase;
import org.jooq.meta.vertica.VerticaDatabase;
import org.jooq.meta.yugabytedb.YugabyteDBDatabase;

/**
 * A common utility class that provides access to various {@link Database}
 * implementations and {@link SQLDialect}s.
 *
 * @author Lukas Eder
 */
public class Databases {

    /**
     * Get a reference to a {@link Database} class for a given {@link SQLDialect}.
     */
    public static final Class<? extends Database> databaseClass(SQLDialect dialect) {
        Class<? extends Database> result = JDBCDatabase.class;

        switch (dialect.family()) {

            case ACCESS:           result = JDBCDatabase.class;             break;
            case ASE:              result = ASEDatabase.class;              break;
            case AURORA_MYSQL:     result = AuroraMySQLDatabase.class;      break;
            case BIGQUERY:         result = BigQueryDatabase.class;         break;
            case COCKROACHDB:      result = CockroachDBDatabase.class;      break;
            case DATABRICKS:       result = DatabricksDatabase.class;       break;
            case DB2:              result = DB2Database.class;              break;
            case EXASOL:           result = ExasolDatabase.class;           break;
            case HANA:             result = HanaDatabase.class;             break;
            case INFORMIX:         result = InformixDatabase.class;         break;
            case INGRES:           result = IngresDatabase.class;           break;
            case MEMSQL:           result = MemSQLDatabase.class;           break;
            case ORACLE:           result = OracleDatabase.class;           break;
            case REDSHIFT:         result = RedshiftDatabase.class;         break;
            case SNOWFLAKE:        result = SnowflakeDatabase.class;        break;
            case SQLDATAWAREHOUSE: result = SQLDataWarehouseDatabase.class; break;
            case SQLSERVER:        result = SQLServerDatabase.class;        break;
            case SYBASE:           result = SybaseDatabase.class;           break;
            case TERADATA:         result = TeradataDatabase.class;         break;
            case VERTICA:          result = VerticaDatabase.class;          break;


            case CLICKHOUSE:       result = ClickHouseDatabase.class;       break;
            case CUBRID:           result = CUBRIDDatabase.class;           break;
            case DERBY:            result = DerbyDatabase.class;            break;
            case DUCKDB:           result = DuckDBDatabase.class;           break;
            case FIREBIRD:         result = FirebirdDatabase.class;         break;
            case H2:               result = H2Database.class;               break;
            case HSQLDB:           result = HSQLDBDatabase.class;           break;
            case IGNITE:           result = IgniteDatabase.class;           break;
            case MARIADB:          result = MariaDBDatabase.class;          break;
            case MYSQL:            result = MySQLDatabase.class;            break;
            case POSTGRES:         result = PostgresDatabase.class;         break;
            case SQLITE:           result = SQLiteDatabase.class;           break;
            case TRINO:            result = TrinoDatabase.class;            break;
            case YUGABYTEDB:       result = YugabyteDBDatabase.class;       break;

            case DEFAULT:          result = JDBCDatabase.class;             break;
        }

        return result;
    }

    /**
     * Get a {@link Database} instance for a given {@link SQLDialect}.
     */
    public static final Database database(SQLDialect dialect) {
        try {
            Database result = databaseClass(dialect).getDeclaredConstructor().newInstance();
            result.setDialect(dialect);
            return result;
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Cannot create an Database instance for " + dialect, e);
        }
    }
}
