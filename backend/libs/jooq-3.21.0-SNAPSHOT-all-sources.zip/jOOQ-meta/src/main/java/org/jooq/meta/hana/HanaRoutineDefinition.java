/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.hana;

import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.when;
import static org.jooq.meta.hana.sys.Tables.ELEMENT_TYPES;
import static org.jooq.meta.hana.sys.Tables.FUNCTION_PARAMETERS;
import static org.jooq.meta.hana.sys.Tables.PROCEDURE_PARAMETERS;

import java.sql.SQLException;

import org.jooq.Record;
import org.jooq.meta.AbstractRoutineDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultParameterDefinition;
import org.jooq.meta.InOutDefinition;
import org.jooq.meta.ParameterDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.hana.sys.tables.ElementTypes;
import org.jooq.meta.hana.sys.tables.FunctionParameters;
import org.jooq.meta.hana.sys.tables.ProcedureParameters;
import org.jooq.tools.StringUtils;

/**
 * Hana implementation of {@link AbstractRoutineDefinition}
 *
 * @author Lukas Eder
 */
public class HanaRoutineDefinition extends AbstractRoutineDefinition {

    private final Long oid;

    public HanaRoutineDefinition(SchemaDefinition schema, String name, Long oid, String dataType, Number precision, Number scale) {
        super(schema, null, name, null, null);

        if (!StringUtils.isBlank(dataType)) {
            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                dataType,
                precision,
                precision,
                scale,
                null,
                (String) null
            );

            this.returnValue = new DefaultParameterDefinition(this, "RETURN_VALUE", -1, type);
        }

        this.oid = oid;
    }

    @Override
    protected void init0() throws SQLException {
        ProcedureParameters pp = PROCEDURE_PARAMETERS;
        FunctionParameters fp = FUNCTION_PARAMETERS;
        ElementTypes et = ELEMENT_TYPES;

        for (Record record : create()
            .select(
                pp.PARAMETER_TYPE,
                pp.PARAMETER_NAME,
                when(et.DATA_TYPE_NAME.isNotNull(), et.DATA_TYPE_NAME.concat(inline(" ARRAY")))
                    .else_(pp.DATA_TYPE_NAME).as(pp.DATA_TYPE_NAME),
                pp.LENGTH,
                pp.SCALE,
                pp.POSITION)
            .from(pp)
                .leftOuterJoin(et)
                    .on(et.SCHEMA_NAME.eq(pp.SCHEMA_NAME))
                    .and(et.OBJECT_NAME.eq(pp.PROCEDURE_NAME))
                    .and(et.OBJECT_OID.eq(pp.PROCEDURE_OID))
                    .and(et.ELEMENT_NAME.eq(pp.PARAMETER_NAME))
            .where(pp.PROCEDURE_OID.eq(oid))
            .and(pp.SCHEMA_NAME.eq(getSchema().getName()))
            .and(pp.PROCEDURE_NAME.eq(getName()))
            .unionAll(
                select(
                    fp.PARAMETER_TYPE,
                    fp.PARAMETER_NAME,
                    when(et.DATA_TYPE_NAME.isNotNull(), et.DATA_TYPE_NAME.concat(inline(" ARRAY")))
                        .else_(fp.DATA_TYPE_NAME).as(fp.DATA_TYPE_NAME),
                    fp.LENGTH,
                    fp.SCALE,
                    fp.POSITION)
                .from(fp)
                    .leftOuterJoin(et)
                        .on(et.SCHEMA_NAME.eq(fp.SCHEMA_NAME))
                        .and(et.OBJECT_NAME.eq(fp.FUNCTION_NAME))
                        .and(et.OBJECT_OID.eq(fp.FUNCTION_OID))
                        .and(et.ELEMENT_NAME.eq(fp.PARAMETER_NAME))
                .where(fp.PARAMETER_TYPE.ne(inline("RETURN")))
                .and(fp.SCHEMA_NAME.eq(getSchema().getName()))
                .and(fp.FUNCTION_NAME.eq(getName()))
            )
            .orderBy(field(name(pp.POSITION.getName())))) {

            String inOut = record.get(pp.PARAMETER_TYPE);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get(pp.DATA_TYPE_NAME),
                record.get(pp.LENGTH),
                record.get(pp.LENGTH),
                record.get(pp.SCALE),
                null,
                (String) null
            );

            ParameterDefinition parameter = new DefaultParameterDefinition(
                this,
                record.get(pp.PARAMETER_NAME),
                record.get(pp.POSITION, int.class),
                type
            );

            addParameter(InOutDefinition.getFromString(inOut), parameter);
        }
    }
}
