/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.bigquery;

import static org.jooq.impl.DSL.inline;

import java.sql.SQLException;

import org.jooq.Record;
import org.jooq.meta.AbstractRoutineDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultParameterDefinition;
import org.jooq.meta.InOutDefinition;
import org.jooq.meta.ParameterDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.tools.StringUtils;

/**
 * BigQuery implementation of {@link AbstractRoutineDefinition}
 *
 * @author Lukas Eder
 */
public class BigQueryRoutineDefinition extends AbstractRoutineDefinition {

    public BigQueryRoutineDefinition(SchemaDefinition schema, String name, String dataType, Number precision, Number scale) {
        this(schema, name, dataType, precision, scale, false);
    }

    public BigQueryRoutineDefinition(SchemaDefinition schema, String name, String dataType, Number precision, Number scale, boolean aggregate) {
        super(schema, null, name, null, null, aggregate);

        if (!StringUtils.isBlank(dataType)) {
            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                dataType,
                precision,
                precision,
                scale,
                null,
                (String) null
            );

            this.returnValue = new DefaultParameterDefinition(this, "RETURN_VALUE", -1, type);
        }
    }

    @Override
    protected void init0() throws SQLException {
        for (Record record : create().fetch(
            """
            SELECT
              p.PARAMETER_MODE,
              p.PARAMETER_NAME,
              p.DATA_TYPE,
              p.ORDINAL_POSITION
            FROM {0}.INFORMATION_SCHEMA.PARAMETERS p
            WHERE p.SPECIFIC_SCHEMA = {1}
            AND p.SPECIFIC_NAME = {2}
            AND p.IS_RESULT = 'NO'
            ORDER BY p.ORDINAL_POSITION
            """,

                // [#15472] Qualify the INFORMATION_SCHEMA with the dataset, in case it isn't the
                //          JDBC URL's DefaultDataset.
                getSchema().getQualifiedInputNamePart(),

                // Using bind variables seems to cause trouble finding the data set
                inline(getSchema().getName()),
                inline(getInputName())
        )) {
            String inOut = record.get("PARAMETER_MODE", String.class);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get("DATA_TYPE", String.class),
                0,
                0,
                0,
                null,
                (String) null
            );

            ParameterDefinition parameter = new DefaultParameterDefinition(
                this,
                record.get("PARAMETER_NAME", String.class),
                record.get("ORDINAL_POSITION", int.class),
                type
            );

            addParameter(InOutDefinition.getFromString(inOut), parameter);
        }
    }
}
