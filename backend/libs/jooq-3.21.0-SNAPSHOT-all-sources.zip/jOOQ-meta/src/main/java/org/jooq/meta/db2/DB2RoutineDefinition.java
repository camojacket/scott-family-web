/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.db2;

import static org.jooq.impl.DSL.noCondition;
import static org.jooq.meta.db2.syscat.Tables.FUNCPARMS;
import static org.jooq.meta.db2.syscat.Tables.PROCPARMS;

import java.sql.SQLException;

import org.jooq.Record;
import org.jooq.meta.AbstractRoutineDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultParameterDefinition;
import org.jooq.meta.InOutDefinition;
import org.jooq.meta.ParameterDefinition;
import org.jooq.meta.SchemaDefinition;

/**
 * DB2 implementation of {@link AbstractRoutineDefinition}
 *
 * @author Espen Stromsnes
 * @author Lukas Eder
 */
public class DB2RoutineDefinition extends AbstractRoutineDefinition {

    private final boolean isProcedure;
    private final String  specificName;

    public DB2RoutineDefinition(SchemaDefinition schema, String name, String comment, boolean isProcedure) {
        this(schema, name, comment, isProcedure, null, null);
    }

    public DB2RoutineDefinition(SchemaDefinition schema, String name, String comment, boolean isProcedure, String specificName, String overload) {
        super(schema, null, name, comment, overload);

        this.isProcedure = isProcedure;
        this.specificName = specificName;
    }

    @Override
    protected void init0() throws SQLException {
        if (isProcedure)
            initP();
        else
            initF();
    }

    private void initF() {
        for (Record record : create()
                .select(
                    FUNCPARMS.ROWTYPE,
                    FUNCPARMS.TYPENAME,
                    FUNCPARMS.LENGTH,
                    FUNCPARMS.SCALE,
                    FUNCPARMS.ORDINAL,
                    FUNCPARMS.PARMNAME)
                .from(FUNCPARMS)
                .where(
                    FUNCPARMS.FUNCSCHEMA.equal(getSchema().getName()),
                    FUNCPARMS.FUNCNAME.equal(getName()),
                    FUNCPARMS.functions().ORIGIN.equal("Q"),
                    specificName != null
                        ? FUNCPARMS.functions().SPECIFICNAME.equal(specificName)
                        : noCondition())
                .orderBy(
                    FUNCPARMS.FUNCNAME.asc(),
                    FUNCPARMS.ORDINAL.asc())
                .fetch()) {

            String rowType = record.get(FUNCPARMS.ROWTYPE);
            String dataType = record.get(FUNCPARMS.TYPENAME);
            Integer precision = record.get(FUNCPARMS.LENGTH);
            Short scale = record.get(FUNCPARMS.SCALE);
            int position = record.get(FUNCPARMS.ORDINAL);
            String paramName = record.get(FUNCPARMS.PARMNAME);

            // result after casting
            if ("C".equals(rowType)) {
                DataTypeDefinition type = new DefaultDataTypeDefinition(
                    getDatabase(),
                    getSchema(),
                    dataType,
                    precision,
                    precision,
                    scale,
                    null,
                    (String) null
                );

                addParameter(InOutDefinition.RETURN, new DefaultParameterDefinition(this, "RETURN_VALUE", -1, type));
            }

            // parameter
            else if ("P".equals(rowType)) {
                DataTypeDefinition type = new DefaultDataTypeDefinition(
                    getDatabase(),
                    getSchema(),
                    dataType,
                    precision,
                    precision,
                    scale,
                    null,
                    (String) null
                );

                ParameterDefinition column = new DefaultParameterDefinition(this, paramName, position, type);

                addParameter(InOutDefinition.IN, column);
            }

            // result before casting
            else {
            }
        }
    }

    private void initP() {
        for (Record record : create().select(
                    PROCPARMS.PARMNAME,
                    PROCPARMS.TYPENAME,
                    PROCPARMS.LENGTH,
                    PROCPARMS.SCALE,
                    PROCPARMS.ORDINAL,
                    PROCPARMS.PARM_MODE)
                .from(PROCPARMS)
                .where(PROCPARMS.PROCSCHEMA.equal(getSchema().getName()))
                .and(PROCPARMS.PROCNAME.equal(getName()))
                .and(specificName != null
                    ? PROCPARMS.SPECIFICNAME.equal(specificName)
                    : noCondition())
                .orderBy(PROCPARMS.ORDINAL).fetch()) {

            String paramMode = record.get(PROCPARMS.PARM_MODE);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get(PROCPARMS.TYPENAME),
                record.get(PROCPARMS.LENGTH),
                record.get(PROCPARMS.LENGTH),
                record.get(PROCPARMS.SCALE),
                null,
                (String) null
            );

            addParameter(
                InOutDefinition.getFromString(paramMode),
                new DefaultParameterDefinition(
                    this,
                    record.get(PROCPARMS.PARMNAME),
                    record.get(PROCPARMS.ORDINAL),
                    type));
        }
    }
}
