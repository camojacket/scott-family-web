/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.informix;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;
import static org.jooq.impl.DSL.case_;
import static org.jooq.impl.DSL.count;
import static org.jooq.impl.DSL.currentCatalog;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.nullif;
import static org.jooq.impl.DSL.partitionBy;
import static org.jooq.impl.DSL.row;
import static org.jooq.impl.DSL.rowNumber;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.trim;
import static org.jooq.impl.DSL.when;
import static org.jooq.impl.DSL.zero;
import static org.jooq.impl.SQLDataType.BIGINT;
import static org.jooq.impl.SQLDataType.BOOLEAN;
import static org.jooq.impl.SQLDataType.INTEGER;
import static org.jooq.impl.SQLDataType.NUMERIC;
import static org.jooq.impl.SQLDataType.SMALLINT;
import static org.jooq.impl.SQLDataType.VARCHAR;
import static org.jooq.meta.informix.sys.Tables.SYSCHECKS;
import static org.jooq.meta.informix.sys.Tables.SYSCOLUMNS;
import static org.jooq.meta.informix.sys.Tables.*;
import static org.jooq.meta.informix.sys.Tables.SYSINDEXES;
import static org.jooq.meta.informix.sys.Tables.SYSPROCCOLUMNS;
import static org.jooq.meta.informix.sys.Tables.SYSPROCEDURES;
import static org.jooq.meta.informix.sys.Tables.SYSREFERENCES;
import static org.jooq.meta.informix.sys.Tables.SYSSEQUENCES;
import static org.jooq.meta.informix.sys.Tables.SYSTABLES;
import static org.jooq.meta.informix.sys.Tables.SYSVIEWS;
import static org.jooq.meta.informix.sys.Tables.SYSXTDTYPES;
import static org.jooq.meta.postgres.information_schema.Tables.ROUTINES;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jooq.CommonTableExpression;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Record12;
import org.jooq.Record14;
import org.jooq.Record4;
import org.jooq.Record5;
import org.jooq.Record6;
import org.jooq.ResultQuery;
import org.jooq.SQLDialect;
import org.jooq.SortOrder;
import org.jooq.TriggerExecution;
import org.jooq.TriggerTime;
import org.jooq.TableOptions.TableType;
import org.jooq.conf.RenderQuotedNames;
import org.jooq.conf.Settings;
import org.jooq.exception.ControlFlowSignal;
import org.jooq.impl.DSL;
import org.jooq.impl.QOM.ForeignKeyRule;
import org.jooq.meta.AbstractDatabase;
import org.jooq.meta.AbstractIndexDefinition;
import org.jooq.meta.ArrayDefinition;
import org.jooq.meta.CatalogDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DefaultCheckConstraintDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultIndexColumnDefinition;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.DefaultSequenceDefinition;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.EnumDefinition;
import org.jooq.meta.IndexColumnDefinition;
import org.jooq.meta.IndexDefinition;
import org.jooq.meta.PackageDefinition;
import org.jooq.meta.ResultQueryDatabase;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.SequenceDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.TriggerDefinition;
import org.jooq.meta.UDTDefinition;
import org.jooq.meta.XMLSchemaCollectionDefinition;
import org.jooq.meta.informix.sys.tables.Syschecks;
import org.jooq.meta.informix.sys.tables.Syscolumns;
import org.jooq.meta.informix.sys.tables.Sysconstraints;
import org.jooq.meta.informix.sys.tables.Sysindexes;
import org.jooq.meta.informix.sys.tables.Sysproccolumns;
import org.jooq.meta.informix.sys.tables.Sysprocedures;
import org.jooq.meta.informix.sys.tables.Sysreferences;
import org.jooq.meta.informix.sys.tables.Systables;
import org.jooq.meta.informix.sys.tables.Sysxtdtypes;
import org.jooq.util.informix.InformixDataType;

/**
 * Informix implementation of {@link AbstractDatabase}
 *
 * @author Lukas Eder
 */
public class InformixDatabase extends AbstractDatabase implements ResultQueryDatabase {

    private static final long DEFAULT_SEQUENCE_CACHE    = 20;

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.INFORMIX, new Settings()
            .withRenderQuotedNames(RenderQuotedNames.NEVER)
            .withFetchTrimmedCharValues(true)
        );
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (Record record : primaryKeys(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(SYSTABLES.OWNER));
            String key = record.get(SYSCONSTRAINTS.CONSTRNAME);
            String tableName = record.get(SYSTABLES.TABNAME);
            String columnName = record.get(SYSCOLUMNS.COLNAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addPrimaryKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        for (Record record : uniqueKeys(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(SYSTABLES.OWNER));
            String key = record.get(SYSCONSTRAINTS.CONSTRNAME);
            String tableName = record.get(SYSTABLES.TABNAME);
            String columnName = record.get(SYSCOLUMNS.COLNAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addUniqueKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> primaryKeys(List<String> schemas) {
        return keys(schemas, "P");
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> uniqueKeys(List<String> schemas) {
        return keys(schemas, "U");
    }

    private ResultQuery<Record6<String, String, String, String, String, Integer>> keys(List<String> schemas, String constraintType) {
        Sysconstraints x = SYSCONSTRAINTS.as("x");
        Sysindexes i = SYSINDEXES.as("i");
        Systables t = SYSTABLES.as("t");
        Syscolumns c = SYSCOLUMNS.as("c");
        Field<Short> zero = inline((short) 0);

        CommonTableExpression<?> j = name("j").as(
                      select(i.OWNER, i.TABID, i.IDXNAME, inline( 1).as(c.COLNO), i.PART1 .as("part")).from(i).where(i.PART1 .gt(zero))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 2).as(c.COLNO), i.PART2 .as("part")).from(i).where(i.PART2 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 3).as(c.COLNO), i.PART3 .as("part")).from(i).where(i.PART3 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 4).as(c.COLNO), i.PART4 .as("part")).from(i).where(i.PART4 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 5).as(c.COLNO), i.PART5 .as("part")).from(i).where(i.PART5 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 6).as(c.COLNO), i.PART6 .as("part")).from(i).where(i.PART6 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 7).as(c.COLNO), i.PART7 .as("part")).from(i).where(i.PART7 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 8).as(c.COLNO), i.PART8 .as("part")).from(i).where(i.PART8 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline( 9).as(c.COLNO), i.PART9 .as("part")).from(i).where(i.PART9 .gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(10).as(c.COLNO), i.PART10.as("part")).from(i).where(i.PART10.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(11).as(c.COLNO), i.PART11.as("part")).from(i).where(i.PART11.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(12).as(c.COLNO), i.PART12.as("part")).from(i).where(i.PART12.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(13).as(c.COLNO), i.PART13.as("part")).from(i).where(i.PART13.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(14).as(c.COLNO), i.PART14.as("part")).from(i).where(i.PART14.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(15).as(c.COLNO), i.PART15.as("part")).from(i).where(i.PART15.gt(zero)))
            .unionAll(select(i.OWNER, i.TABID, i.IDXNAME, inline(16).as(c.COLNO), i.PART16.as("part")).from(i).where(i.PART16.gt(zero)))
        );


        return create().with(j)
                .select(
                    trim(currentCatalog()).as("catalog"),
                    trim(t.OWNER).as(SYSTABLES.OWNER),
                    trim(t.TABNAME).as(SYSTABLES.TABNAME),
                    trim(x.CONSTRNAME).as(x.CONSTRNAME),
                    c.COLNAME,
                    field(name(j.getName(), c.COLNO.getName()), INTEGER).as(c.COLNO)
                )
                .from(x)
                    .join(t)
                        .on(x.OWNER.eq(t.OWNER))
                        .and(x.TABID.eq(t.TABID))
                    .join(j)
                        .on(x.OWNER.eq(j.field(i.OWNER)))
                        .and(x.IDXNAME.eq(j.field(i.IDXNAME)))
                        .and(x.TABID.eq(j.field(i.TABID)))
                    .join(c)
                        .on(j.field(i.TABID).eq(c.TABID))
                        .and(field(name(j.getName(), "part"), SMALLINT).eq(c.COLNO))
                .where(x.OWNER.in(schemas))
                .and(x.CONSTRTYPE.eq(inline(constraintType)))
                .orderBy(2, 3, 4, 6);
    }

    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
        Sysreferences r = SYSREFERENCES.as("r");
        Sysconstraints fk = SYSCONSTRAINTS.as("fk");
        Sysindexes fkIndex = SYSINDEXES.as("fkIndex");

        int offset = 0;

        for (Record record : create()
                .select(
                    ++offset > 0 ? r.referencedConstraint().OWNER               : null,
                    ++offset > 0 ? r.referencedConstraint().CONSTRNAME          : null,
                    ++offset > 0 ? r.referencedConstraint().systables().TABNAME : null,
                    ++offset > 0 ? fk.OWNER                                     : null,
                    ++offset > 0 ? fk.CONSTRNAME                                : null,
                    ++offset > 0 ? fk.systables().TABNAME                       : null,

                    fkIndex.PART1,
                    fkIndex.PART2,
                    fkIndex.PART3,
                    fkIndex.PART4,
                    fkIndex.PART5,
                    fkIndex.PART6,
                    fkIndex.PART7,
                    fkIndex.PART8,
                    fkIndex.PART9,
                    fkIndex.PART10,
                    fkIndex.PART11,
                    fkIndex.PART12,
                    fkIndex.PART13,
                    fkIndex.PART14,
                    fkIndex.PART15,
                    fkIndex.PART16,

                    case_(r.DELRULE)
                        .when(inline("C"), ForeignKeyRule.CASCADE.name())
                        .when(inline("R"), ForeignKeyRule.RESTRICT.name())
                        .as(r.DELRULE),
                    case_(r.UPDRULE)
                        .when(inline("C"), ForeignKeyRule.CASCADE.name())
                        .when(inline("R"), ForeignKeyRule.RESTRICT.name())
                        .as(r.UPDRULE)
                )
                .from(r)
                .join(fk)
                .on(r.CONSTRID.eq(fk.CONSTRID))
                .join(fkIndex)
                .on(fk.OWNER.eq(fkIndex.OWNER))
                .and(fk.IDXNAME.eq(fkIndex.IDXNAME))
                .where(fk.OWNER.in(getInputSchemata()))
                .and(r.referencedConstraint().OWNER.in(getInputSchemata()))
                .orderBy(
                    fk.OWNER.asc(),
                    fk.CONSTRNAME.asc())
        ) {
            SchemaDefinition foreignKeySchema = getSchema(record.get(fk.OWNER).trim());
            SchemaDefinition uniqueKeySchema = getSchema(record.get(r.referencedConstraint().OWNER).trim());

            String foreignKey = record.get(fk.CONSTRNAME).trim();
            String foreignKeyTableName = record.get(fk.systables().TABNAME).trim();
            String uniqueKey = record.get(r.referencedConstraint().CONSTRNAME).trim();
            String uniqueKeyTableName = record.get(r.referencedConstraint().systables().TABNAME).trim();
            ForeignKeyRule deleteRule = record.get(r.DELRULE, ForeignKeyRule.class);
            ForeignKeyRule updateRule = record.get(r.UPDRULE, ForeignKeyRule.class);

            for (int i = offset; i < record.size(); i++) {
                int foreignKeyColumnNo = record.get(i, int.class);

                if (foreignKeyColumnNo != 0) {
                    TableDefinition foreignKeyTable = getTable(foreignKeySchema, foreignKeyTableName);
                    TableDefinition uniqueKeyTable = getTable(uniqueKeySchema, uniqueKeyTableName);

                    if (foreignKeyTable != null && uniqueKeyTable != null)
                        relations.addForeignKey(
                            foreignKey,
                            foreignKeyTable,
                            foreignKeyTable.getColumns().get(foreignKeyColumnNo - 1),
                            uniqueKey,
                            uniqueKeyTable,
                            true,
                            deleteRule,
                            updateRule
                        );
                }
            }
        }
    }

    @Override
    protected void loadCheckConstraints(DefaultRelations relations) throws SQLException {
        Syschecks ch = SYSCHECKS.as("ch");

        create().select(
                    ch.sysconstraints().systables().OWNER,
                    ch.sysconstraints().systables().TABNAME,
                    ch.sysconstraints().CONSTRNAME,
                    ch.SEQNO,
                    ch.CHECKTEXT
                )
                .from(ch)
                .where(ch.sysconstraints().CONSTRTYPE.eq(inline("C")))
                .and(ch.TYPE.eq(inline("T")))
                .and(ch.sysconstraints().systables().OWNER.in(getInputSchemata()))
                .orderBy(1, 2, 3, 4)
                .fetchGroups(
                    new Field[] {
                        ch.sysconstraints().systables().OWNER,
                        ch.sysconstraints().systables().TABNAME,
                        ch.sysconstraints().CONSTRNAME
                    },
                    new Field[] {
                        ch.SEQNO,
                        ch.CHECKTEXT
                    }
                )
                .forEach((k, v) -> {
            SchemaDefinition schema = getSchema(k.get(ch.sysconstraints().systables().OWNER).trim());
            TableDefinition table = getTable(schema, k.get(ch.sysconstraints().systables().TABNAME).trim());

            if (table != null) {
                StringBuilder sb = new StringBuilder();

                // The above SQL ORDER BY produces stable sorted groups since
                // we're using LinkedHashMaps in fetchGroups(). No need to sort again
                for (String part : v.getValues(ch.CHECKTEXT))
                    sb.append(part);

                relations.addCheckConstraint(table, new DefaultCheckConstraintDefinition(
                    schema,
                    table,
                    k.get(ch.sysconstraints().CONSTRNAME).trim(),
                    sb.toString().trim()
                ));
            }
        });
    }

    @Override
    protected List<CatalogDefinition> getCatalogs0() throws SQLException {
        List<CatalogDefinition> result = new ArrayList<>();
        result.add(new CatalogDefinition(this, "", ""));
        return result;
    }

    @Override
    protected List<SchemaDefinition> getSchemata0() throws SQLException {
        return
        create().selectDistinct(trim(SYSTABLES.OWNER))
                .from(SYSTABLES)
                .collect(mapping(r -> new SchemaDefinition(this, r.value1(), ""), toList()));
    }

    @Override
    public ResultQuery<Record4<String, String, String, String>> sources(List<String> schemas) {
        // [#9818] TODO: Implement this. It's a bit more tricky for Informix, as the view text is scattered across rows.
        return null;
    }

    @Override
    public ResultQuery<Record5<String, String, String, String, String>> comments(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record12<String, String, String, String, Integer, Integer, Long, Long, BigDecimal, BigDecimal, Boolean, Long>> sequences(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).cast(VARCHAR).as("catalog"),
                trim(SYSTABLES.OWNER).as(SYSTABLES.OWNER),
                trim(SYSTABLES.TABNAME).as(SYSTABLES.TABNAME),
                inline("BIGINT").as("type_name"),
                inline(null, INTEGER).cast(INTEGER).as("precision"),
                inline(null, INTEGER).cast(INTEGER).as("scale"),
                SYSSEQUENCES.START_VAL,
                nullif(SYSSEQUENCES.INC_VAL, inline(1L)).as(SYSSEQUENCES.INC_VAL),
                nullif(SYSSEQUENCES.MIN_VAL, inline(1L)).coerce(NUMERIC).as(SYSSEQUENCES.MIN_VAL),
                nullif(SYSSEQUENCES.MAX_VAL, inline(Long.MAX_VALUE)).coerce(NUMERIC).as(SYSSEQUENCES.MAX_VAL),
                SYSSEQUENCES.CYCLE.coerce(BOOLEAN),
                nullif(SYSSEQUENCES.CACHE.coerce(BIGINT), inline(DEFAULT_SEQUENCE_CACHE)).as(SYSSEQUENCES.CACHE)
            )
            .from(SYSTABLES)
            .join(SYSSEQUENCES).on(SYSTABLES.TABID.eq(SYSSEQUENCES.TABID))
            .where(SYSTABLES.OWNER.in(schemas));
    }

    @Override
    protected List<SequenceDefinition> getSequences0() throws SQLException {
        List<SequenceDefinition> result = new ArrayList<>();

        for (Record record : sequences(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(SYSTABLES.OWNER));
            String name = record.get(SYSTABLES.TABNAME);
            DefaultDataTypeDefinition type = new DefaultDataTypeDefinition(
                this,
                schema,
                InformixDataType.BIGINT.getTypeName()
            );

            result.add(new DefaultSequenceDefinition(
                schema,
                name,
                type,
                null,
                record.get(SYSSEQUENCES.START_VAL),
                record.get(SYSSEQUENCES.INC_VAL),
                record.get(SYSSEQUENCES.MIN_VAL),
                record.get(SYSSEQUENCES.MAX_VAL),
                record.get(SYSSEQUENCES.CYCLE, Boolean.class),
                record.get(SYSSEQUENCES.CACHE)
            ));
        }

        return result;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> enums(List<String> schemas) {
        return null;
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (Record record : create()
                .select(
                    trim(SYSTABLES.OWNER).as(SYSTABLES.OWNER),
                    trim(SYSTABLES.TABNAME).as(SYSTABLES.TABNAME),
                    trim(when(SYSTABLES.TABTYPE.eq(inline("V")), inline(TableType.VIEW.name()))
                    .else_(inline(TableType.TABLE.name()))).as("table_type"),
                    SYSTABLES.TABID)
                .from(SYSTABLES)
                .where(SYSTABLES.OWNER.in(getInputSchemata()))
                .and(SYSTABLES.TABTYPE.in("T", "V"))) {

            SchemaDefinition schema = getSchema(record.get("owner", String.class).trim());
            TableType tableType = record.get("table_type", TableType.class);
            String source = null;

            if (tableType == TableType.VIEW) {
                Integer tabId = record.get(SYSTABLES.TABID);

                source =
                create().select(SYSVIEWS.VIEWTEXT)
                        .from(SYSVIEWS)
                        .where(SYSVIEWS.TABID.eq(tabId))
                        .orderBy(SYSVIEWS.SEQNO)
                        .collect(mapping(r -> r.value1(), joining()));
            }

            result.add(new InformixTableDefinition(schema, record.get("tabname", String.class), "", tableType, source));
        }

        return result;
    }

    Map<TableDefinition, List<ColumnDefinition>> lookupColumnByIndex;

    private ColumnDefinition lookupColumnByIndex(TableDefinition table, int index) {
        if (lookupColumnByIndex == null) {
            lookupColumnByIndex = new HashMap<>();

            Syscolumns col = SYSCOLUMNS.as("c");
            Systables tab = SYSTABLES.as("t");

            for (Record r : create()
                .select(
                    trim(tab.OWNER).as(tab.OWNER),
                    trim(tab.TABNAME).as(tab.TABNAME),
                    trim(col.COLNAME).as(col.COLNAME),
                    col.COLNO)
                .from(tab)
                .join(col).on(tab.TABID.eq(col.TABID))
                .where(tab.OWNER.in(getInputSchemata()))
                .orderBy(
                    tab.OWNER,
                    tab.TABNAME,
                    col.COLNO)
            ) {
                SchemaDefinition s = getSchema(r.get(tab.OWNER));

                if (s != null) {
                    TableDefinition t = getTable(s, r.get(tab.TABNAME));

                    if (t != null) {
                        ColumnDefinition c = t.getColumn(r.get(col.COLNAME));

                        // [#16237] ColumnDefinition can be null if it's hidden or excluded
                        lookupColumnByIndex.computeIfAbsent(t, x -> new ArrayList<>()).add(c);
                    }
                }
            }
        }

        List<ColumnDefinition> list = lookupColumnByIndex.get(table);
        if (list == null)
            return null;

        if (list.size() <= index)
            return null;

        return list.get(index);
    }

    @Override
    protected List<IndexDefinition> getIndexes0() throws SQLException {
        List<IndexDefinition> result = new ArrayList<>();

        indexLoop:
        for (final Record record : create().select(
                trim(SYSINDEXES.systables().OWNER).as(SYSTABLES.OWNER),
                trim(SYSINDEXES.systables().TABNAME).as(SYSTABLES.TABNAME),
                trim(SYSINDEXES.IDXNAME).as(SYSINDEXES.IDXNAME),
                trim(SYSINDEXES.IDXTYPE).as(SYSINDEXES.IDXTYPE),
                SYSINDEXES.PART1,
                SYSINDEXES.PART2,
                SYSINDEXES.PART3,
                SYSINDEXES.PART4,
                SYSINDEXES.PART5,
                SYSINDEXES.PART6,
                SYSINDEXES.PART7,
                SYSINDEXES.PART8,
                SYSINDEXES.PART9,
                SYSINDEXES.PART10,
                SYSINDEXES.PART11,
                SYSINDEXES.PART12,
                SYSINDEXES.PART13,
                SYSINDEXES.PART14,
                SYSINDEXES.PART15,
                SYSINDEXES.PART16
            )
            .from(SYSINDEXES)
            .where(SYSINDEXES.OWNER.in(getInputSchemata()))
            .and(getIncludeSystemIndexes()
                ? noCondition()
                : row(SYSINDEXES.systables().TABID, SYSINDEXES.OWNER, SYSINDEXES.IDXNAME).notIn(
                    select(SYSCONSTRAINTS.TABID, SYSCONSTRAINTS.OWNER, SYSCONSTRAINTS.IDXNAME)
                    .from(SYSCONSTRAINTS)
                  ))
            .orderBy(1, 2, 3)
        ) {
            final SchemaDefinition tableSchema = getSchema(record.get(SYSTABLES.OWNER));
            if (tableSchema == null)
                continue indexLoop;

            final String indexName = record.get(SYSINDEXES.IDXNAME);
            final String tableName = record.get(SYSTABLES.TABNAME);
            final TableDefinition table = getTable(tableSchema, tableName);
            if (table == null)
                continue indexLoop;

            class SkipIndex extends ControlFlowSignal {}

            try {
                result.add(new AbstractIndexDefinition(tableSchema, indexName, table, "U".equals(record.get(SYSINDEXES.IDXTYPE, String.class))) {
                    List<IndexColumnDefinition> indexColumns = new ArrayList<>();

                    {
                        for (int i = 4; i < record.size(); i++) {
                            int colNo = record.get(i, int.class);

                            if (colNo != 0) {
                                ColumnDefinition column = lookupColumnByIndex(table, colNo - 1);

                                // [#16237] If column is hidden or excluded
                                if (column == null)
                                    throw new SkipIndex();

                                indexColumns.add(new DefaultIndexColumnDefinition(
                                    this,
                                    column,
                                    SortOrder.ASC,
                                    i - 3
                                ));
                            }
                        }
                    }

                    @Override
                    protected List<IndexColumnDefinition> getIndexColumns0() {
                        return indexColumns;
                    }
                });
            }
            catch (SkipIndex ignore) {}
        }

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();

        Sysprocedures p = SYSPROCEDURES.as("p");
        Sysproccolumns c = SYSPROCCOLUMNS.as("c");
        Sysxtdtypes t = SYSXTDTYPES.as("t");

        for (Record record : create()
            .select(
                trim(p.OWNER).as(p.OWNER),
                trim(p.PROCNAME).as(p.PROCNAME),
                p.PROCID,
                when(count().over(partitionBy(p.OWNER, p.PROCNAME)).gt(inline(1)),
                    rowNumber().over(partitionBy(p.OWNER, p.PROCNAME).orderBy(p.PARAMTYPES.cast(VARCHAR)))).as("overload"),
                field("informix.schema_coltypename({0}, {1})", String.class, c.PARAMTYPE, c.PARAMXID).as("datatype"),
                trim(t.OWNER).as(t.OWNER),
                trim(t.NAME).as(t.NAME),

                // [#9945] TODO: Do we need to reverse engineer DATETIME precision as well, as for tables?
                field("informix.schema_precision({0}, {1}, {2})", int.class, c.PARAMTYPE, c.PARAMXID, c.PARAMLEN).as("precision"),
                field("informix.schema_numscale({0}, {1})", int.class, c.PARAMTYPE, c.PARAMLEN).as("scale")
            )
            .from(p)
            .leftJoin(c)
                .on(p.PROCID.eq(c.PROCID))
                .and(c.PARAMNAME.isNull())
                .and(c.PARAMID.eq(zero()))

                // 0 = Parameter is of unknown type 1 = Parameter is INPUT mode 2 = Parameter is INOUT mode 3 = Parameter is multiple return value 4 = Parameter is OUT mode 5 = Parameter is a return value
                // https://www.ibm.com/docs/en/informix-servers/14.10?topic=tables-sysproccolumns
                .and(c.PARAMATTR.in(inline(3), inline(5)))
            .leftJoin(t)
                .on(c.PARAMTYPE.eq(t.TYPE))
                .and(c.PARAMXID.eq(t.EXTENDED_ID))
            .where(p.OWNER.in(getInputSchemata()))
        ) {
            result.add(new InformixRoutineDefinition(
                getSchema(record.get(p.OWNER)),
                record.get(p.PROCNAME),
                record.get(p.PROCID),
                record.get("datatype", String.class),
                record.get("precision", Integer.class),
                record.get("scale", Integer.class),
                record.get("overload", String.class),
                false,
                name(
                    record.get(t.OWNER),
                    record.get(t.NAME)
                )
            ));
        }

        return result;
    }

    @Override
    protected List<PackageDefinition> getPackages0() throws SQLException {
        List<PackageDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<EnumDefinition> getEnums0() throws SQLException {
        List<EnumDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        List<DomainDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    public ResultQuery<Record14<String, String, String, String, String, String, Boolean, Boolean, Boolean, String, String, String, Integer, String>> triggers(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> synonyms(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).cast(VARCHAR).as("table_catalog"),
                trim(SYSSYNTABLE.referencingTable().OWNER),
                trim(SYSSYNTABLE.referencingTable().TABNAME),
                inline(null, VARCHAR).cast(VARCHAR).as("synonym_catalog"),
                trim(SYSSYNTABLE.referencedTable().OWNER),
                trim(SYSSYNTABLE.referencedTable().TABNAME)
            )
            .from(SYSSYNTABLE)
            .where(SYSSYNTABLE.referencingTable().OWNER.in(schemas))
            .orderBy(
                SYSSYNTABLE.referencingTable().OWNER,
                SYSSYNTABLE.referencingTable().TABNAME);
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> generators(List<String> schemas) {
        return null;
    }

    @Override
    protected List<XMLSchemaCollectionDefinition> getXMLSchemaCollections0() throws SQLException {
        List<XMLSchemaCollectionDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<UDTDefinition> getUDTs0() throws SQLException {
        List<UDTDefinition> result = new ArrayList<>();

        for (Record r : create()
            .select(
                trim(SYSXTDTYPES.OWNER).as(SYSXTDTYPES.OWNER),
                trim(SYSXTDTYPES.NAME).as(SYSXTDTYPES.NAME),
                SYSXTDTYPES.EXTENDED_ID)
            .from(SYSXTDTYPES)
            .where(SYSXTDTYPES.OWNER.in(getInputSchemata()))
            .and(SYSXTDTYPES.MODE.eq(inline("R")))
            .orderBy(SYSXTDTYPES.OWNER, SYSXTDTYPES.NAME)
        ) {
            SchemaDefinition schema = getSchema(r.get(SYSXTDTYPES.OWNER));

            if (schema != null)
                result.add(new InformixUDTDefinition(schema, r.get(SYSXTDTYPES.NAME), r.get(SYSXTDTYPES.EXTENDED_ID)));
        }

        return result;
    }

    @Override
    protected List<ArrayDefinition> getArrays0() throws SQLException {
        List<ArrayDefinition> result = new ArrayList<>();
        return result;
    }
}
