/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.informix;

import static org.jooq.impl.DSL.bitAnd;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.greatest;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.position;
import static org.jooq.impl.DSL.substring;
import static org.jooq.impl.DSL.trim;
import static org.jooq.impl.DSL.when;
import static org.jooq.meta.informix.sys.Tables.SYSCOLUMNS;
import static org.jooq.meta.informix.sys.Tables.SYSDEFAULTS;
import static org.jooq.meta.informix.sys.Tables.SYSTABLES;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.Field;
import org.jooq.Record;
import org.jooq.TableOptions.TableType;
import org.jooq.impl.DSL;
import org.jooq.meta.AbstractTableDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultColumnDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.informix.sys.tables.Syscolumns;
import org.jooq.meta.informix.sys.tables.Sysdefaults;
import org.jooq.meta.informix.sys.tables.Systables;

/**
 * Informix table definition
 *
 * @author Lukas Eder
 */
public class InformixTableDefinition extends AbstractTableDefinition {

    public InformixTableDefinition(SchemaDefinition schema, String name, String comment) {
        super(schema, name, comment);
    }

    public InformixTableDefinition(SchemaDefinition schema, String name, String comment, TableType tableType, String source) {
        super(schema, name, comment, tableType, source);
    }

    @Override
    public List<ColumnDefinition> getElements0() throws SQLException {
        List<ColumnDefinition> result = new ArrayList<>();

        Syscolumns c = SYSCOLUMNS.as("c");
        Systables t = SYSTABLES.as("t");
        Sysdefaults d = SYSDEFAULTS.as("d");

        // http://publib.boulder.ibm.com/infocenter/idshelp/v10/index.jsp?topic=/com.ibm.sqlr.doc/sqlrmst41.htm
        Field<String> colTypeName = field("informix.schema_coltypename({0}, {1})", String.class, c.COLTYPE, c.EXTENDED_ID);

        for (Record record : create().select(
                    trim(c.COLNAME).as(c.COLNAME),
                    c.COLNO,

                    trim(colTypeName).as("coltype"),
                    field("informix.schema_charlen({0}, {1}, {2})", int.class, c.COLTYPE, c.EXTENDED_ID, c.COLLENGTH).as("collength"),

                    // [#9945] Reverse engineer timestamp precision: https://stackoverflow.com/a/60676213/521799
                    when(colTypeName.eq(inline("DATETIME")), greatest(inline(0), bitAnd(c.COLLENGTH, inline((short) 15)).minus(inline(10))))
                    .else_(field("informix.schema_precision({0}, {1}, {2})", int.class, c.COLTYPE, c.EXTENDED_ID, c.COLLENGTH)).as("precision"),
                    field("informix.schema_numscale({0}, {1})", int.class, c.COLTYPE, c.COLLENGTH).as("scale"),
                    field("informix.schema_isnullable({0})", boolean.class, c.COLTYPE).as("nullable"),
                    field("informix.schema_isautoincr({0})", String.class, c.COLTYPE).as("identity"),

                    // [#15683] SYSDEFAULT values can't be trusted, for some data types.
                    trim(when(colTypeName.in(inline("BOOLEAN"), inline("CHAR"), inline("VARCHAR"), inline("LVARCHAR")),
                            inline("'").concat(trim(d.DEFAULT)).concat(inline("'")))
                        .else_(substring(d.DEFAULT, position(d.DEFAULT, inline(" ")))))
                        .as(d.DEFAULT),

                    trim(c.sysxtdtypes().OWNER).as("udt_schema"),
                    trim(c.sysxtdtypes().NAME).as("udt_name")
                )
                .from(t)
                .join(c).on(t.TABID.eq(c.TABID))
                .leftOuterJoin(d).on(d.TABID.eq(c.TABID).and(d.COLNO.eq(c.COLNO)))
                .where(t.OWNER.eq(getSchema().getInputName()))
                .and(t.TABNAME.eq(getInputName()))
                .orderBy(c.COLNO)) {

            // Informix reports TEXT, BLOB types and similar to be of length Integer.MAX_VALUE
            // We shouldn't use this information in jOOQ, though.
            Integer collength = record.get("collength", Integer.class);
            if (Integer.valueOf(Integer.MAX_VALUE).equals(collength))
                collength = 0;

            SchemaDefinition typeSchema = null;

            String schemaName = record.get("udt_schema", String.class);
            if (schemaName != null)
                typeSchema = getDatabase().getSchema(schemaName);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                typeSchema == null ? getSchema() : typeSchema,
                record.get("coltype", String.class),
                collength,
                record.get("precision", Integer.class),
                record.get("scale", Integer.class),
                record.get("nullable", boolean.class),
                record.get(d.DEFAULT),
                name(
                    record.get("udt_schema", String.class),
                    record.get("udt_name", String.class)
                )
            );

            result.add(new DefaultColumnDefinition(
            	getDatabase().getTable(getSchema(), getName()),
                record.get(c.COLNAME),
                result.size() + 1,
                type,
                record.get("identity", boolean.class),
                null
            ));
        }

        return result;
    }
}
