/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta.hana;

import static org.jooq.impl.DSL.condition;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.when;
import static org.jooq.impl.SQLDataType.BOOLEAN;
import static org.jooq.meta.h2.information_schema.Tables.COLUMNS;
import static org.jooq.meta.hana.sys.Tables.ELEMENT_TYPES;
import static org.jooq.meta.hana.sys.Tables.TABLE_COLUMNS;
import static org.jooq.meta.hana.sys.Tables.VIEW_COLUMNS;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.Condition;
import org.jooq.Record;
import org.jooq.TableOptions.TableType;
import org.jooq.meta.AbstractTableDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultColumnDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.hana.sys.tables.ElementTypes;
import org.jooq.meta.hana.sys.tables.TableColumns;
import org.jooq.meta.hana.sys.tables.ViewColumns;

import org.jetbrains.annotations.NotNull;

/**
 * @author Lukas Eder
 */
public class HanaTableDefinition extends AbstractTableDefinition {

    public HanaTableDefinition(SchemaDefinition schema, String name, String comment) {
        this(schema, name, comment, TableType.TABLE, null);
    }

    public HanaTableDefinition(SchemaDefinition schema, String name, String comment, TableType tableType, String source) {
        super(schema, name, comment, tableType, source);
    }

	@Override
	public List<ColumnDefinition> getElements0() throws SQLException {
		List<ColumnDefinition> result = new ArrayList<>();

        TableColumns tc = TABLE_COLUMNS;
        ViewColumns vc = VIEW_COLUMNS;
        ElementTypes et = ELEMENT_TYPES;
        Condition hidden = tc.IS_HIDDEN.eq(inline("TRUE"));

        for (Record record : create()
            .select(
                tc.COLUMN_NAME,
                tc.POSITION,
                when(et.DATA_TYPE_NAME.isNotNull(), et.DATA_TYPE_NAME.concat(inline(" ARRAY")))
                    .else_(tc.DATA_TYPE_NAME).as(tc.DATA_TYPE_NAME),
                tc.GENERATION_TYPE,
                tc.GENERATED_ALWAYS_AS,
                tc.IS_NULLABLE,
                tc.DEFAULT_VALUE,

                // [#9945] TIMESTAMP precision is in the SCALE column, not the LENGTH column
                when(tc.DATA_TYPE_NAME.like(inline("TIME%")), tc.SCALE).else_(tc.LENGTH).as(tc.LENGTH),
                when(tc.DATA_TYPE_NAME.like(inline("TIME%")), inline(0)).else_(tc.SCALE).as(tc.SCALE),
                tc.COMMENTS,
                hidden
            )
            .from(tc
                .leftOuterJoin(et)
                .on(et.SCHEMA_NAME.eq(tc.SCHEMA_NAME))
                .and(et.OBJECT_NAME.eq(tc.TABLE_NAME))
                .and(et.OBJECT_OID.eq(tc.TABLE_OID))
                .and(et.ELEMENT_NAME.eq(tc.COLUMN_NAME)))
            .where(tc.SCHEMA_NAME.equal(getSchema().getName()))
            .and(tc.TABLE_NAME.equal(getName()))
            .and(!getDatabase().getIncludeInvisibleColumns()
                ? tc.IS_HIDDEN.ne(inline("TRUE"))
                : noCondition())
            .unionAll(
                 select(
                    vc.COLUMN_NAME,
                    vc.POSITION,
                    when(et.DATA_TYPE_NAME.isNotNull(), et.DATA_TYPE_NAME.concat(inline(" ARRAY")))
                        .else_(vc.DATA_TYPE_NAME).as(vc.DATA_TYPE_NAME),
                    vc.GENERATION_TYPE,
                    vc.GENERATED_ALWAYS_AS,
                    vc.IS_NULLABLE,
                    vc.DEFAULT_VALUE,

                    // [#9945] TIMESTAMP precision is in the SCALE column, not the LENGTH column
                    when(vc.DATA_TYPE_NAME.like(inline("TIME%")), vc.SCALE).else_(vc.LENGTH).as(vc.LENGTH),
                    when(vc.DATA_TYPE_NAME.like(inline("TIME%")), inline(0)).else_(vc.SCALE).as(vc.SCALE),
                    vc.COMMENTS,
                    vc.IS_HIDDEN.eq(inline("TRUE"))
                )
                .from(vc
                    .leftOuterJoin(et)
                    .on(et.SCHEMA_NAME.eq(vc.SCHEMA_NAME))
                    .and(et.OBJECT_NAME.eq(vc.VIEW_NAME))
                    .and(et.OBJECT_OID.eq(vc.VIEW_OID))
                    .and(et.ELEMENT_NAME.eq(vc.COLUMN_NAME)))
                .where(vc.SCHEMA_NAME.equal(getSchema().getName()))
                .and(vc.VIEW_NAME.equal(getName()))
                .and(!getDatabase().getIncludeInvisibleColumns()
                    ? vc.IS_HIDDEN.ne(inline("TRUE"))
                    : noCondition())
            )
            .orderBy(field(name(tc.POSITION.getName())))
        ) {
            boolean identity = "BY DEFAULT AS IDENTITY".equalsIgnoreCase(record.get(tc.GENERATION_TYPE));
            boolean generated = "ALWAYS AS".equalsIgnoreCase(record.get(tc.GENERATION_TYPE));

            DefaultDataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get(tc.DATA_TYPE_NAME),
                record.get(tc.LENGTH),
                record.get(tc.LENGTH),
                record.get(tc.SCALE),
                record.get(tc.IS_NULLABLE, boolean.class),
                generated ? null : record.get(tc.DEFAULT_VALUE)
            ).generatedAlwaysAs(generated ? record.get(tc.GENERATED_ALWAYS_AS) : null);

            if (getDatabase().getInvisibleColumnsAsHidden())
                type.hidden(record.get(hidden));

			result.add(new DefaultColumnDefinition(
			    getDatabase().getTable(getSchema(), getName()),
			    record.get(tc.COLUMN_NAME, String.class),
                result.size() + 1,
			    type,
			    identity,
			    record.get(tc.COMMENTS)
		    ));
		}

		return result;
	}
}
