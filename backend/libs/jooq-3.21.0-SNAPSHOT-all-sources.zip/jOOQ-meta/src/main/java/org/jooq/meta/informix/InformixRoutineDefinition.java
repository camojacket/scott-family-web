/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.informix;

import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.trim;
import static org.jooq.meta.InOutDefinition.IN;
import static org.jooq.meta.InOutDefinition.INOUT;
import static org.jooq.meta.InOutDefinition.OUT;
import static org.jooq.meta.InOutDefinition.RETURN;
import static org.jooq.meta.informix.sys.Tables.SYSPROCCOLUMNS;
import static org.jooq.meta.informix.sys.Tables.SYSXTDTYPES;
import static org.jooq.meta.postgres.information_schema.Tables.ROUTINES;

import java.sql.SQLException;

import org.jooq.Name;
import org.jooq.Record;
import org.jooq.meta.AbstractRoutineDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultParameterDefinition;
import org.jooq.meta.ParameterDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.informix.sys.tables.Sysproccolumns;
import org.jooq.meta.informix.sys.tables.Sysxtdtypes;
import org.jooq.tools.StringUtils;

/**
 * Informix implementation of {@link AbstractRoutineDefinition}
 *
 * @author Lukas Eder
 */
public class InformixRoutineDefinition extends AbstractRoutineDefinition {

    private final int procid;

    public InformixRoutineDefinition(SchemaDefinition schema, String name, int procid, String dataType, Number precision, Number scale, String overload) {
        this(schema, name, procid, dataType, precision, scale, overload, false);
    }

    public InformixRoutineDefinition(SchemaDefinition schema, String name, int procid, String dataType, Number precision, Number scale, String overload, boolean aggregate) {
        this(schema, name, procid, dataType, precision, scale, overload, aggregate, null);
    }

    public InformixRoutineDefinition(SchemaDefinition schema, String name, int procid, String dataType, Number precision, Number scale, String overload, boolean aggregate, Name udtName) {
        super(schema, null, name, null, overload, aggregate);

        if (!StringUtils.isBlank(dataType)) {
            SchemaDefinition typeSchema = schema;

            if (udtName != null && udtName.qualified())
                typeSchema = getDatabase().getSchema(udtName.qualifier().last());

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                schema,
                dataType,
                precision,
                precision,
                scale,
                null,
                (String) null,
                udtName
            );

            this.returnValue = new DefaultParameterDefinition(this, "RETURN_VALUE", -1, type);
        }

        this.procid = procid;
    }

    @Override
    protected void init0() throws SQLException {
        Sysproccolumns c = SYSPROCCOLUMNS.as("c");
        Sysxtdtypes t = SYSXTDTYPES.as("t");

        for (Record record : create()
            .select(
                c.PARAMATTR,
                trim(c.PARAMNAME).as(c.PARAMNAME),
                field("informix.schema_coltypename({0}, {1})", String.class, c.PARAMTYPE, c.PARAMXID).as("datatype"),
                trim(t.OWNER).as(t.OWNER),
                trim(t.NAME).as(t.NAME),

                // [#9945] TODO: Do we need to reverse engineer DATETIME precision as well, as for tables?
                field("informix.schema_precision({0}, {1}, {2})", int.class, c.PARAMTYPE, c.PARAMXID, c.PARAMLEN).as("precision"),
                field("informix.schema_numscale({0}, {1})", int.class, c.PARAMTYPE, c.PARAMLEN).as("scale"),
                c.PARAMID)
            .from(c)
            .leftJoin(t)
                .on(c.PARAMTYPE.eq(t.TYPE))
                .and(c.PARAMXID.eq(t.EXTENDED_ID))
            .where(c.PROCID.eq(procid))

            // 0 = Parameter is of unknown type 1 = Parameter is INPUT mode 2 = Parameter is INOUT mode 3 = Parameter is multiple return value 4 = Parameter is OUT mode 5 = Parameter is a return value
            // https://www.ibm.com/docs/en/informix-servers/14.10?topic=tables-sysproccolumns
            .and(c.PARAMATTR.in(inline(1), inline(2), inline(4)))
            .orderBy(c.PARAMID)
        ) {
            SchemaDefinition typeSchema = null;

            String schemaName = record.get(t.OWNER);
            if (schemaName != null)
                typeSchema = getDatabase().getSchema(schemaName);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                typeSchema == null ? getSchema() : typeSchema,
                record.get("datatype", String.class),
                record.get("precision", Integer.class),
                record.get("precision", Integer.class),
                record.get("scale", Integer.class),
                null,
                (String) null,
                name(
                    record.get(t.OWNER),
                    record.get(t.NAME)
                )
            );

            ParameterDefinition parameter = new DefaultParameterDefinition(
                this,
                record.get(c.PARAMNAME),
                record.get(c.PARAMID),
                type
            );

            // 0 = Parameter is of unknown type 1 = Parameter is INPUT mode 2 = Parameter is INOUT mode 3 = Parameter is multiple return value 4 = Parameter is OUT mode 5 = Parameter is a return value
            // https://www.ibm.com/docs/en/informix-servers/14.10?topic=tables-sysproccolumns
            switch (record.get(c.PARAMATTR, int.class)) {
                case 1: addParameter(IN, parameter); break;
                case 2: addParameter(INOUT, parameter); break;
                case 4: addParameter(OUT, parameter); break;
                case 3:
                case 5: addParameter(RETURN, parameter); break;
            }
        }
    }
}
