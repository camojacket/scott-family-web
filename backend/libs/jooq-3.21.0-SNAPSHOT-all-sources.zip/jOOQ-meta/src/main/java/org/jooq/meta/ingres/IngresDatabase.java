/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.ingres;

import static org.jooq.Records.mapping;
import static org.jooq.impl.DSL.row;
import static org.jooq.impl.DSL.trim;
import static org.jooq.meta.ingres.ingres.Tables.IICONSTRAINTS;
import static org.jooq.meta.ingres.ingres.Tables.IIDB_COMMENTS;
import static org.jooq.meta.ingres.ingres.Tables.IIREF_CONSTRAINTS;
import static org.jooq.meta.ingres.ingres.Tables.IISCHEMA;
import static org.jooq.meta.ingres.ingres.Tables.IISEQUENCES;
import static org.jooq.meta.ingres.ingres.Tables.IITABLES;
import static org.jooq.meta.ingres.ingres.tables.Iikeys.IIKEYS;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.Record4;
import org.jooq.Result;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.jooq.meta.AbstractDatabase;
import org.jooq.meta.ArrayDefinition;
import org.jooq.meta.CatalogDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.DefaultSequenceDefinition;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.EnumDefinition;
import org.jooq.meta.PackageDefinition;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.SequenceDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.TriggerDefinition;
import org.jooq.meta.UDTDefinition;
import org.jooq.meta.XMLSchemaCollectionDefinition;
import org.jooq.meta.ingres.ingres.tables.Iiconstraints;
import org.jooq.meta.ingres.ingres.tables.IidbComments;
import org.jooq.meta.ingres.ingres.tables.Iikeys;
import org.jooq.meta.ingres.ingres.tables.IirefConstraints;
import org.jooq.meta.ingres.ingres.tables.Iischema;
import org.jooq.meta.ingres.ingres.tables.Iisequences;
import org.jooq.meta.ingres.ingres.tables.Iitables;

/**
 * @author Lukas Eder
 */
public class IngresDatabase extends AbstractDatabase {

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.INGRES);
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys("P")) {
            SchemaDefinition schema = getSchema(record.get(trim(Iiconstraints.SCHEMA_NAME)));
            String key = record.get(trim(Iiconstraints.CONSTRAINT_NAME));
            String tableName = record.get(trim(Iiconstraints.TABLE_NAME));
            String columnName = record.get(trim(Iikeys.COLUMN_NAME));

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addPrimaryKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys("U")) {
            SchemaDefinition schema = getSchema(record.get(trim(Iiconstraints.SCHEMA_NAME)));
            String key = record.get(trim(Iiconstraints.CONSTRAINT_NAME));
            String tableName = record.get(trim(Iiconstraints.TABLE_NAME));
            String columnName = record.get(trim(Iikeys.COLUMN_NAME));

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addUniqueKey(key, table, table.getColumn(columnName));
        }
    }

    private Result<Record4<String, String, String, String>> fetchKeys(String constraintType) {
        return create().select(
                    trim(Iiconstraints.SCHEMA_NAME),
                    trim(Iiconstraints.TABLE_NAME),
                    trim(Iiconstraints.CONSTRAINT_NAME),
                    trim(Iikeys.COLUMN_NAME))
                .from(IICONSTRAINTS)
                .join(IIKEYS)
                .on(row(Iiconstraints.CONSTRAINT_NAME, Iiconstraints.SCHEMA_NAME)
                    .eq(Iikeys.CONSTRAINT_NAME, Iikeys.SCHEMA_NAME))
                .where(Iiconstraints.SCHEMA_NAME.in(getInputSchemata()))
                .and(trim(Iiconstraints.CONSTRAINT_TYPE).equal(constraintType))
                .orderBy(
                    Iiconstraints.SCHEMA_NAME.asc(),
                    Iiconstraints.TABLE_NAME.asc(),
                    Iiconstraints.CONSTRAINT_NAME.asc(),
                    Iikeys.KEY_POSITION.asc())
                .fetch();
    }

    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
        Result<?> result = create()
            .select(
                trim(IirefConstraints.REF_SCHEMA_NAME),
                trim(IirefConstraints.REF_TABLE_NAME),
                trim(IirefConstraints.REF_CONSTRAINT_NAME),
                trim(IirefConstraints.UNIQUE_CONSTRAINT_NAME),
                trim(IirefConstraints.UNIQUE_TABLE_NAME),
                trim(IirefConstraints.UNIQUE_SCHEMA_NAME),
                trim(Iikeys.COLUMN_NAME))
            .from(IICONSTRAINTS)
            .join(IIREF_CONSTRAINTS)
            .on(row(Iiconstraints.CONSTRAINT_NAME, Iiconstraints.SCHEMA_NAME)
                .eq(IirefConstraints.REF_CONSTRAINT_NAME, IirefConstraints.REF_SCHEMA_NAME))
            .join(IIKEYS)
            .on(row(IirefConstraints.REF_CONSTRAINT_NAME, IirefConstraints.REF_SCHEMA_NAME)
                .eq(Iikeys.CONSTRAINT_NAME, Iikeys.SCHEMA_NAME))
            .where(Iiconstraints.SCHEMA_NAME.in(getInputSchemata()))
            .and(Iiconstraints.CONSTRAINT_TYPE.equal("R"))
            .orderBy(
                IirefConstraints.REF_SCHEMA_NAME.asc(),
                IirefConstraints.REF_TABLE_NAME.asc(),
                IirefConstraints.REF_CONSTRAINT_NAME.asc(),
                Iikeys.KEY_POSITION.asc())
            .fetch();

        for (Record record : result) {
            SchemaDefinition foreignKeySchema = getSchema(record.get(trim(IirefConstraints.REF_SCHEMA_NAME)));
            SchemaDefinition uniqueKeySchema = getSchema(record.get(trim(IirefConstraints.UNIQUE_SCHEMA_NAME)));

            String foreignKey = record.get(trim(IirefConstraints.REF_CONSTRAINT_NAME));
            String foreignKeyTableName = record.get(trim(IirefConstraints.REF_TABLE_NAME));
            String foreignKeyColumn = record.get(trim(Iikeys.COLUMN_NAME));
            String uniqueKey = record.get(trim(IirefConstraints.UNIQUE_CONSTRAINT_NAME));
            String uniqueKeyTableName = record.get(trim(IirefConstraints.UNIQUE_TABLE_NAME));

            TableDefinition foreignKeyTable = getTable(foreignKeySchema, foreignKeyTableName);
            TableDefinition uniqueKeyTable = getTable(uniqueKeySchema, uniqueKeyTableName);

            if (foreignKeyTable != null && uniqueKeyTable != null)
                relations.addForeignKey(
                    foreignKey,
                    foreignKeyTable,
                    foreignKeyTable.getColumn(foreignKeyColumn),
                    uniqueKey,
                    uniqueKeyTable
                );
        }
    }

    @Override
    protected void loadCheckConstraints(DefaultRelations r) throws SQLException {
        // Currently not supported
    }

    @Override
    protected List<CatalogDefinition> getCatalogs0() throws SQLException {
        List<CatalogDefinition> result = new ArrayList<>();
        result.add(new CatalogDefinition(this, "", ""));
        return result;
    }

    @Override
    protected List<SchemaDefinition> getSchemata0() throws SQLException {
        return create()
            .select(trim(Iischema.SCHEMA_NAME))
            .from(IISCHEMA)
            .fetch(mapping(s -> new SchemaDefinition(this, s, "")));
    }

    @Override
    protected List<SequenceDefinition> getSequences0() throws SQLException {
        List<SequenceDefinition> result = new ArrayList<>();

        for (Record record : create().select(
                    trim(Iisequences.SEQ_OWNER),
                    trim(Iisequences.SEQ_NAME),
                    trim(Iisequences.DATA_TYPE))
                .from(IISEQUENCES)
                .where(Iisequences.SEQ_OWNER.in(getInputSchemata()))
                .orderBy(
                    Iisequences.SEQ_OWNER,
                    Iisequences.SEQ_NAME)
                .fetch()) {

            SchemaDefinition schema = getSchema(record.get(trim(Iisequences.SEQ_OWNER)));

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                this, schema,
                record.get(trim(Iisequences.DATA_TYPE))
            );

            result.add(new DefaultSequenceDefinition(
                schema, record.get(trim(Iisequences.SEQ_NAME)), type));
        }

        return result;
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (Record record : create().select(
                    trim(Iitables.TABLE_OWNER),
                    trim(Iitables.TABLE_NAME),
                    trim(IidbComments.LONG_REMARK))
                .from(IITABLES)
                .leftOuterJoin(IIDB_COMMENTS)
                .on(Iitables.TABLE_NAME.equal(IidbComments.OBJECT_NAME))
                .and(Iitables.TABLE_OWNER.equal(IidbComments.OBJECT_OWNER))
                .and(IidbComments.OBJECT_TYPE.equal("T"))
                .and(IidbComments.TEXT_SEQUENCE.equal(1L))
                .where(Iitables.TABLE_OWNER.in(getInputSchemata()))
                .orderBy(
                    trim(Iitables.TABLE_OWNER),
                    trim(Iitables.TABLE_NAME))
                .fetch()) {

            result.add(new IngresTableDefinition(
                getSchema(record.get(trim(Iitables.TABLE_OWNER))),
                record.get(trim(Iitables.TABLE_NAME)),
                record.get(trim(IidbComments.LONG_REMARK))));
        }

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<PackageDefinition> getPackages0() throws SQLException {
        List<PackageDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<EnumDefinition> getEnums0() throws SQLException {
        List<EnumDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        List<DomainDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<TriggerDefinition> getTriggers0() throws SQLException {
        List<TriggerDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<XMLSchemaCollectionDefinition> getXMLSchemaCollections0() throws SQLException {
        List<XMLSchemaCollectionDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<UDTDefinition> getUDTs0() throws SQLException {
        List<UDTDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<ArrayDefinition> getArrays0() throws SQLException {
        List<ArrayDefinition> result = new ArrayList<>();
        return result;
    }
}
