/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit http://www.jooq.org/licenses
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: http://www.jooq.org/licensing
 */
package org.jooq.meta;



import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import org.jooq.Pro;
import org.jooq.TriggerEvent;
import org.jooq.TriggerExecution;
import org.jooq.TriggerTime;

/**
 * @author Lukas Eder
 */
@Pro
public class DefaultTriggerDefinition extends AbstractDefinition implements TriggerDefinition {

    final TableDefinition        table;
    final List<ColumnDefinition> columns;
    final TriggerTime            time;
    final Set<TriggerEvent>      events;
    final TriggerExecution       execution;
    final String                 condition;
    final int                    actionOrder;

    public DefaultTriggerDefinition(
        Database database,
        SchemaDefinition schema,
        TableDefinition table,
        List<ColumnDefinition> columns,
        String name,
        String comment,
        String source,
        TriggerTime time,
        Set<TriggerEvent> events,
        TriggerExecution execution,
        String condition,
        int actionOrder
    ) {
        super(database, schema, null, name, comment, null, source);

        this.table = table;
        this.columns = new ArrayList<>(columns);
        this.time = time;
        this.events = EnumSet.copyOf(events);
        this.execution = execution;
        this.condition = condition;
        this.actionOrder = actionOrder;
    }

    @Override
    public TableDefinition getTable() {
        return table;
    }

    @Override
    public List<ColumnDefinition> getColumns() {
        return columns;
    }

    @Override
    public TriggerTime getTime() {
        return time;
    }

    @Override
    public Set<TriggerEvent> getEvents() {
        return events;
    }

    @Override
    public TriggerExecution getExecution() {
        return execution;
    }

    @Override
    public String getCondition() {
        return condition;
    }

    @Override
    public int getActionOrder() {
        return actionOrder;
    }

    @Override
    public String getReferencingOldTable() {
        // [#11248] TODO: Support this
        return null;
    }

    @Override
    public String getReferencingNewTable() {
        // [#11248] TODO: Support this
        return null;
    }
}


