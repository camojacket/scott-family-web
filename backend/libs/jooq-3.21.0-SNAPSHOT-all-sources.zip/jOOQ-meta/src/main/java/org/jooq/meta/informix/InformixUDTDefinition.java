/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.informix;

import static org.jooq.impl.DSL.bitAnd;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.greatest;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.trim;
import static org.jooq.impl.DSL.when;
import static org.jooq.meta.informix.sys.Tables.SYSATTRTYPES;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.jooq.Field;
import org.jooq.Record;
import org.jooq.meta.AbstractUDTDefinition;
import org.jooq.meta.AttributeDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultAttributeDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.informix.sys.tables.Sysattrtypes;

public class InformixUDTDefinition extends AbstractUDTDefinition {

    private final int extendedId;

    public InformixUDTDefinition(SchemaDefinition schema, String name, int extendedId) {
        super(schema, null, name, "");

        this.extendedId = extendedId;
    }

    @Override
    protected List<AttributeDefinition> getElements0() throws SQLException {
        List<AttributeDefinition> result = new ArrayList<>();

        Sysattrtypes a = SYSATTRTYPES.as("a");

        Field<String> typeName = field("informix.schema_coltypename({0}, {1})", String.class, a.TYPE, a.EXTENDED_ID);

        for (Record record : create()
            .select(
                trim(a.FIELDNAME).as(a.FIELDNAME),
                a.FIELDNO,

                trim(

                    // [#18663] E.g. informix.boolean, informix.blob
                    when(typeName.eq(inline("FIXED UDT")).and(a.sysxtdtypes().OWNER.eq(inline("informix"))), a.sysxtdtypes().NAME)

                    // [#18663] E.g. informix.lvarchar
                    .when(typeName.eq(inline("VARIABLE UDT")).and(a.sysxtdtypes().OWNER.eq(inline("informix"))), a.sysxtdtypes().NAME)
                    .else_(typeName)
                ).as("type"),
                field("informix.schema_charlen({0}, {1}, {2})", int.class, a.TYPE, a.EXTENDED_ID, a.LENGTH).as("length"),

                // [#9945] Reverse engineer timestamp precision: https://stackoverflow.com/a/60676213/521799
                when(typeName.eq(inline("DATETIME")), greatest(inline(0), bitAnd(a.LENGTH, inline((short) 15)).minus(inline(10))))
                .else_(field("informix.schema_precision({0}, {1}, {2})", int.class, a.TYPE, a.EXTENDED_ID, a.LENGTH)).as("precision"),
                field("informix.schema_numscale({0}, {1})", int.class, a.TYPE, a.LENGTH).as("scale"),

                trim(a.sysxtdtypes().OWNER).as("udt_schema"),
                trim(a.sysxtdtypes().NAME).as("udt_name"))
            .from(a)
            .where(a.EXTENDED_ID.eq(extendedId))
            .and(a.FIELDNO.gt(inline((short) 0)))
            .orderBy(a.FIELDNO)
        ) {
            SchemaDefinition typeSchema = null;

            String schemaName = record.get("udt_schema", String.class);
            if (schemaName != null)
                typeSchema = getDatabase().getSchema(schemaName);

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                typeSchema == null ? getSchema() : typeSchema,
                record.get("type", String.class),
                record.get("length", Integer.class),
                record.get("precision", Integer.class),
                record.get("scale", Integer.class),
                true,
                (String) null,
                name(
                    record.get("udt_schema", String.class),
                    record.get("udt_name", String.class)
                )
            );

            AttributeDefinition column = new DefaultAttributeDefinition(
                this,
                record.get(a.FIELDNAME),
                record.get(a.FIELDNO),
                type
            );

            result.add(column);
        }

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() {
        return Collections.emptyList();
    }
}
