/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta.bigquery;

import static java.util.Arrays.asList;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.nvl;
import static org.jooq.impl.SQLDataType.VARCHAR;
import static org.jooq.meta.hsqldb.information_schema.Tables.ELEMENT_TYPES;
import static org.jooq.meta.hsqldb.information_schema.Tables.ROUTINES;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.Record12;
import org.jooq.Record14;
import org.jooq.Record4;
import org.jooq.Record5;
import org.jooq.Record6;
import org.jooq.ResultQuery;
import org.jooq.SQLDialect;
import org.jooq.TableOptions.TableType;
import org.jooq.impl.DSL;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.ResultQueryDatabase;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.hsqldb.HSQLDBRoutineDefinition;
import org.jooq.meta.jdbc.JDBCDatabase;
import org.jooq.tools.JooqLogger;

/**
 * @author Lukas Eder
 */
public class BigQueryDatabase extends JDBCDatabase implements ResultQueryDatabase {

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.BIGQUERY);
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (SchemaDefinition schema : getSchemata()) {
            for (Record record : create().fetch(
                """
                SELECT
                  t.TABLE_SCHEMA,
                  t.TABLE_NAME,
                  t.TABLE_TYPE,
                  TRIM(o.OPTION_VALUE, '"') AS COMMENT
                FROM {0}.INFORMATION_SCHEMA.TABLES t
                LEFT JOIN {0}.INFORMATION_SCHEMA.TABLE_OPTIONS o
                ON t.TABLE_CATALOG = o.TABLE_CATALOG
                AND t.TABLE_SCHEMA = o.TABLE_SCHEMA
                AND t.TABLE_NAME = o.TABLE_NAME
                AND o.OPTION_NAME = 'description'
                WHERE t.TABLE_SCHEMA = {1}
                ORDER BY 1, 2
                """,

                // [#15472] Qualify the INFORMATION_SCHEMA with the dataset, in case it isn't the
                //          JDBC URL's DefaultDataset.
                schema.getQualifiedInputNamePart(),

                // Using bind variables seems to cause trouble finding the data set
                inline(schema.getName())
            )) {
                String name = record.get("TABLE_NAME", String.class);
                TableType tableType = record.get("TABLE_TYPE", TableType.class);
                String comment = record.get("COMMENT", String.class);

                result.add(new BigQueryTableDefinition(schema, name, comment, tableType, null));
            }
        }

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();

        for (SchemaDefinition schema : getSchemata()) {
            for (Record record : create().fetch(
                """
                SELECT
                  r.ROUTINE_SCHEMA,
                  r.ROUTINE_NAME,
                  r.DATA_TYPE,
                  r.ROUTINE_TYPE = 'AGGREGATE FUNCTION' AS AGGREGATE
                FROM {0}.INFORMATION_SCHEMA.ROUTINES r
                WHERE r.ROUTINE_SCHEMA = {1}
                ORDER BY 1, 2
                """,

                // [#15472] Qualify the INFORMATION_SCHEMA with the dataset, in case it isn't the
                //          JDBC URL's DefaultDataset.
                schema.getQualifiedInputNamePart(),

                // Using bind variables seems to cause trouble finding the data set
                inline(schema.getName())
            )) {
                result.add(new BigQueryRoutineDefinition(
                    getSchema(record.get("ROUTINE_SCHEMA", String.class)),
                    record.get("ROUTINE_NAME", String.class),
                    record.get("DATA_TYPE", String.class),
                    0,
                    0,
                    record.get("AGGREGATE", boolean.class)
                ));
            }
        }

        return result;
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (SchemaDefinition schema : getSchemata()) {
            for (Record record : create().fetch(
                """
                SELECT
                  k.TABLE_CATALOG,
                  k.TABLE_SCHEMA,
                  k.TABLE_NAME,
                  k.CONSTRAINT_NAME,
                  k.COLUMN_NAME,
                  k.ORDINAL_POSITION
                FROM
                {0}.INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
                JOIN {0}.INFORMATION_SCHEMA.TABLE_CONSTRAINTS c
                  ON k.TABLE_CATALOG = c.TABLE_CATALOG
                  AND k.TABLE_SCHEMA = c.TABLE_SCHEMA
                  AND k.TABLE_NAME = c.TABLE_NAME
                  AND k.CONSTRAINT_NAME = c.CONSTRAINT_NAME
                WHERE c.TABLE_SCHEMA = {1}
                AND c.CONSTRAINT_TYPE = 'PRIMARY KEY'
                ORDER BY
                  k.TABLE_SCHEMA,
                  k.TABLE_NAME,
                  k.CONSTRAINT_NAME,
                  k.ORDINAL_POSITION
                """,

                // [#15472] Qualify the INFORMATION_SCHEMA with the dataset, in case it isn't the
                //          JDBC URL's DefaultDataset.
                schema.getQualifiedInputNamePart(),

                // Using bind variables seems to cause trouble finding the data set
                inline(schema.getName())

            )) {
                String key = record.get("CONSTRAINT_NAME", String.class);
                String tableName = record.get("TABLE_NAME", String.class);
                String columnName = record.get("COLUMN_NAME", String.class);

                TableDefinition table = getTable(schema, tableName);
                if (table != null)
                    relations.addPrimaryKey(key, table, table.getColumn(columnName));
            }
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        // [#17226] Unique keys not yet supported
    }

    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> primaryKeys(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> uniqueKeys(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record12<String, String, String, String, Integer, Integer, Long, Long, BigDecimal, BigDecimal, Boolean, Long>> sequences(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> enums(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record4<String, String, String, String>> sources(List<String> schemas) {
        String sqlTemplate =
            """
            SELECT
              CAST(NULL AS STRING) AS TABLE_CATALOG,
              TABLE_SCHEMA,
              TABLE_NAME,
              CASE
                WHEN LOWER(VIEW_DEFINITION) LIKE 'create%' THEN VIEW_DEFINITION
                ELSE 'create view `' || TABLE_NAME || '` AS ' || VIEW_DEFINITION
              END AS VIEW_DEFINITION
            FROM INFORMATION_SCHEMA.VIEWS
            """;

        String sql;

        // [#15473] MetaGeneration is calling to produce MetaSQL. The query will be patched in MetaImpl
        if (asList("s").equals(schemas)) {
            sql = sqlTemplate + "ORDER BY TABLE_SCHEMA, TABLE_NAME\n";
        }
        else {
            sql = schemas
                .stream()
                .map(s -> sqlTemplate.replace("FROM INFORMATION_SCHEMA.VIEWS", "FROM " + create().render(DSL.name(s)) + ".INFORMATION_SCHEMA.VIEWS"))
                .collect(Collectors.joining("UNION ALL\n"));
        }

        return create()

            // Using bind variables seems to cause trouble finding the data set
            // DSL.list(schemas.stream().map(DSL::val).collect(toList()))
            .resultQuery(sql)
            .coerce(
                field("TABLE_CATALOG", VARCHAR),
                field("TABLE_SCHEMA", VARCHAR),
                field("TABLE_NAME", VARCHAR),
                field("VIEW_DEFINITION", VARCHAR)
            )
        ;
    }

    @Override
    public ResultQuery<Record5<String, String, String, String, String>> comments(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record14<String, String, String, String, String, String, Boolean, Boolean, Boolean, String, String, String, Integer, String>> triggers(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> synonyms(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> generators(List<String> schemas) {
        return null;
    }
}
