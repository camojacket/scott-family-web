/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.ase;

import static java.util.Arrays.asList;
import static org.jooq.Records.mapping;
import static org.jooq.impl.DSL.concat;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.val;
import static org.jooq.meta.ase.sys.Tables.SYSINDEXES;
import static org.jooq.meta.ase.sys.Tables.SYSREFERENCES;
import static org.jooq.meta.ase.sys.Tables.SYSUSERS;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Record10;
import org.jooq.Result;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.jooq.meta.AbstractDatabase;
import org.jooq.meta.ArrayDefinition;
import org.jooq.meta.CatalogDefinition;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.EnumDefinition;
import org.jooq.meta.PackageDefinition;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.SequenceDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.TriggerDefinition;
import org.jooq.meta.UDTDefinition;
import org.jooq.meta.XMLSchemaCollectionDefinition;
import org.jooq.tools.JooqLogger;

/**
 * Sybase Adaptive Server implementation of {@link AbstractDatabase}
 *
 * @author Lukas Eder
 */
public class ASEDatabase extends AbstractDatabase {

    private static final JooqLogger log = JooqLogger.getLogger(ASEDatabase.class);

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.ASE);
    }

    private SchemaDefinition getSchema() {
        List<SchemaDefinition> schemata = getSchemata();

        if (schemata.size() > 1) {
            log.error("NOT SUPPORTED", "jOOQ does not support multiple schemata in Sybase ASE.");
            log.error("-----------------------------------------------------------------------");

            // TODO [#1098] Support this also for Sybase ASE
        }

        return schemata.get(0);
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys(PK_INCL, PK_EXCL)) {
            String keyName = record.get(0, String.class);
            TableDefinition table = getTable(getSchema(), record.get(1, String.class));

            if (table != null) {
                for (int i = 0; i < 8; i++) {
                    if (record.get(2 + i) == null)
                        break;

                    relations.addPrimaryKey(keyName, table, table.getColumn(record.get(2 + i, String.class)));
                }
            }
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys(UK_INCL, UK_EXCL)) {
            String keyName = record.get(0, String.class);
            TableDefinition table = getTable(getSchema(), record.get(1, String.class));

            if (table != null) {
                for (int i = 0; i < 8; i++) {
                    if (record.get(2 + i) == null)
                        break;

                    relations.addUniqueKey(keyName, table, table.getColumn(record.get(2 + i, String.class)));
                }
            }
        }
    }

    private static final int PK_INCL = 2048;
    private static final int PK_EXCL = 64;
    private static final int UK_INCL = 4096 | 2;
    private static final int UK_EXCL = 2048 | 64;

    /**
     * The underlying query of this method was found here:
     * <p>
     * <a href=
     * "http://www.dbforums.com/sybase/1625012-sysindexes-question-testing-unique-clustered-indexes.html"
     * >http://www.dbforums.com/sybase/1625012-sysindexes-question-testing-
     * unique-clustered-indexes.html</a>
     */
    private Result<Record10<String, String, String, String, String, String, String, String, String, String>> fetchKeys(int incl, int excl) {
        Field<String> table = field("object_name(id)", String.class);
        Field<String> key = field("name", String.class);

        return create().select(
                    concat(table, val("__"), key),
                    table,
                    field("index_col(object_name(id), indid, 1)", String.class),
                    field("index_col(object_name(id), indid, 2)", String.class),
                    field("index_col(object_name(id), indid, 3)", String.class),
                    field("index_col(object_name(id), indid, 4)", String.class),
                    field("index_col(object_name(id), indid, 5)", String.class),
                    field("index_col(object_name(id), indid, 6)", String.class),
                    field("index_col(object_name(id), indid, 7)", String.class),
                    field("index_col(object_name(id), indid, 8)", String.class))
            .from(SYSINDEXES)
            .where("status & ? = 0", excl)
            .and("status & ? <> 0", incl)
            .orderBy(SYSINDEXES.ID)
            .fetch();
    }

    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
        Field<String> fkTable = field("object_name(tableid)", String.class);
        Field<String> fk = field("object_name(constrid)", String.class);
        Field<String> pkTable = field("object_name(reftabid)", String.class);
        Field<String> pk = field("index_name(pmrydbid, reftabid, indexid)", String.class);

        for (Record record : create().select(
                fkTable.as("fk_table"),
                pkTable.as("pk_table"),
                concat(fkTable, val("__"), fk).as("fk"),
                concat(pkTable, val("__"), pk).as("pk"),
                field("col_name(tableid, fokey1)", String.class),
                field("col_name(tableid, fokey2)", String.class),
                field("col_name(tableid, fokey3)", String.class),
                field("col_name(tableid, fokey4)", String.class),
                field("col_name(tableid, fokey5)", String.class),
                field("col_name(tableid, fokey6)", String.class),
                field("col_name(tableid, fokey7)", String.class),
                field("col_name(tableid, fokey8)", String.class),
                field("col_name(tableid, fokey9)", String.class),
                field("col_name(tableid, fokey10)", String.class),
                field("col_name(tableid, fokey11)", String.class),
                field("col_name(tableid, fokey12)", String.class),
                field("col_name(tableid, fokey13)", String.class),
                field("col_name(tableid, fokey14)", String.class),
                field("col_name(tableid, fokey15)", String.class),
                field("col_name(tableid, fokey16)", String.class),
                field("object_owner_id(tableid)"))
            .from(SYSREFERENCES)
            .fetch()) {

            TableDefinition foreignKeyTable = getTable(getSchema(), record.get("fk_table", String.class));
            TableDefinition uniqueKeyTable = getTable(getSchema(), record.get("pk_table", String.class));

            if (foreignKeyTable != null && uniqueKeyTable != null) {
                for (int i = 0; i < 15; i++) {
                    if (record.get(i + 4) == null)
                        break;

                    String foreignKeyName = record.get("fk", String.class);
                    String foreignKeyColumnName = record.get(i + 4, String.class);
                    String uniqueKeyName = record.get("pk", String.class);

                    relations.addForeignKey(
                        foreignKeyName,
                        foreignKeyTable,
                        foreignKeyTable.getColumn(foreignKeyColumnName),
                        uniqueKeyName,
                        uniqueKeyTable
                    );
                }
            }
        }
    }

    @Override
    protected void loadCheckConstraints(DefaultRelations r) throws SQLException {
        // Currently not supported
    }

    @Override
    protected List<CatalogDefinition> getCatalogs0() throws SQLException {
        List<CatalogDefinition> result = new ArrayList<>();
        result.add(new CatalogDefinition(this, "", ""));
        return result;
    }

    @Override
    protected List<SchemaDefinition> getSchemata0() throws SQLException {
        return create()
            .select(SYSUSERS.NAME)
            .from(SYSUSERS)
            .fetch(mapping(s -> new SchemaDefinition(this, s, "")));
    }

    @Override
    protected List<SequenceDefinition> getSequences0() throws SQLException {
        List<SequenceDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (Record record : fetchTables()) {
            SchemaDefinition schema = getSchema(record.get("Owner", String.class));
            String name = record.get("Name", String.class);

            result.add(new ASETableDefinition(schema, name, null));
        }

        return result;
    }

    private List<Record> fetchTables() {
        List<Record> result = new ArrayList<>();

        // [#9443] Find the first non-update-count result set that contains the Object_type column
        for (Result<Record> r : create().fetchMany("sp_help"))
            if (r.field("Object_type") != null)
                for (Record record : r)
                    if (asList("view", "user table", "system table").contains(record.get("Object_type", String.class)))
                        if (getInputSchemata().contains(record.get("Owner", String.class)))
                            result.add(record);

        return result;
    }

    @SuppressWarnings("unused")
    private List<Record> fetchRoutines() {
        List<Record> result = new ArrayList<>();

        // [#9443] Find the first non-update-count result set that contains the Object_type column
        for (Result<Record> r : create().fetchMany("sp_help"))
            if (r.field("Object_type") != null)
                for (Record record : r)
                    if (asList("stored procedure").contains(record.get("Object_type", String.class)))
                        if (getInputSchemata().contains(record.get("Owner", String.class)))
                            result.add(record);

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();

        // [#1507] This was contributed by Mark. It will be correctly
        // implemented at a later stage

//        for (Record record : fetchRoutines()) {
//            SchemaDefinition schema = getSchema(record.get("Owner", String.class));
//            String name = record.get("Name", String.class);
//            result.add(new ASERoutineDefinition(schema, null, name, null, null, null));
//        }

        return result;
    }

    @Override
    protected List<PackageDefinition> getPackages0() throws SQLException {
        List<PackageDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<EnumDefinition> getEnums0() throws SQLException {
        List<EnumDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        List<DomainDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<TriggerDefinition> getTriggers0() throws SQLException {
        List<TriggerDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<XMLSchemaCollectionDefinition> getXMLSchemaCollections0() throws SQLException {
        List<XMLSchemaCollectionDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<UDTDefinition> getUDTs0() throws SQLException {
        List<UDTDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<ArrayDefinition> getArrays0() throws SQLException {
        List<ArrayDefinition> result = new ArrayList<>();
        return result;
    }
}
