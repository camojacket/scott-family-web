/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.db2;

import static java.util.Arrays.asList;
import static org.jooq.Records.mapping;
import static org.jooq.impl.DSL.case_;
import static org.jooq.impl.DSL.cast;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.listAgg;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.nullif;
import static org.jooq.impl.DSL.one;
import static org.jooq.impl.DSL.power;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.trim;
import static org.jooq.impl.DSL.val;
import static org.jooq.impl.DSL.when;
import static org.jooq.impl.SQLDataType.BIGINT;
import static org.jooq.impl.SQLDataType.BOOLEAN;
import static org.jooq.impl.SQLDataType.INTEGER;
import static org.jooq.impl.SQLDataType.NUMERIC;
import static org.jooq.impl.SQLDataType.VARCHAR;
import static org.jooq.meta.db2.syscat.Tables.CHECKS;
import static org.jooq.meta.db2.syscat.Tables.COLUMNS;
import static org.jooq.meta.db2.syscat.Tables.DATATYPES;
import static org.jooq.meta.db2.syscat.Tables.FUNCPARMS;
import static org.jooq.meta.db2.syscat.Tables.FUNCTIONS;
import static org.jooq.meta.db2.syscat.Tables.INDEXCOLUSE;
import static org.jooq.meta.db2.syscat.Tables.KEYCOLUSE;
import static org.jooq.meta.db2.syscat.Tables.PROCEDURES;
import static org.jooq.meta.db2.syscat.Tables.PROCPARMS;
import static org.jooq.meta.db2.syscat.Tables.REFERENCES;
import static org.jooq.meta.db2.syscat.Tables.SCHEMATA;
import static org.jooq.meta.db2.syscat.Tables.SEQUENCES;
import static org.jooq.meta.db2.syscat.Tables.TABLES;
import static org.jooq.meta.db2.syscat.Tables.TRIGGERS;
import static org.jooq.meta.db2.syscat.Tables.VIEWS;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Record12;
import org.jooq.Record14;
import org.jooq.Record4;
import org.jooq.Record5;
import org.jooq.Record6;
import org.jooq.Records;
import org.jooq.Result;
import org.jooq.ResultQuery;
import org.jooq.SQLDialect;
import org.jooq.SortOrder;
import org.jooq.Table;
import org.jooq.TableOptions.TableType;
import org.jooq.TriggerExecution;
import org.jooq.TriggerTime;
import org.jooq.conf.Settings;
import org.jooq.impl.DSL;
import org.jooq.impl.QOM.ForeignKeyRule;
import org.jooq.impl.QOM.GenerationOption;
import org.jooq.meta.AbstractDatabase;
import org.jooq.meta.AbstractIndexDefinition;
import org.jooq.meta.ArrayDefinition;
import org.jooq.meta.CatalogDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultCheckConstraintDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultIndexColumnDefinition;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.DefaultSequenceDefinition;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.EnumDefinition;
import org.jooq.meta.IndexColumnDefinition;
import org.jooq.meta.IndexDefinition;
import org.jooq.meta.PackageDefinition;
import org.jooq.meta.ResultQueryDatabase;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.SequenceDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.UDTDefinition;
import org.jooq.meta.XMLSchemaCollectionDefinition;
import org.jooq.meta.db2.syscat.tables.Funcparms;
import org.jooq.meta.db2.syscat.tables.Functions;
import org.jooq.meta.db2.syscat.tables.Procedures;
import org.jooq.meta.db2.syscat.tables.Procparms;
import org.jooq.meta.db2.syscat.tables.Tables;
import org.jooq.meta.db2.syscat.tables.Triggers;

/**
 * DB2 implementation of {@link AbstractDatabase}
 *
 * @author Espen Stromsnes
 * @author Lukas Eder
 */
public class DB2Database extends AbstractDatabase implements ResultQueryDatabase {

    private static final long DEFAULT_SEQUENCE_CACHE = 20;

    private Boolean           is10_1;

    boolean is10_1() {

        // [#2864] The ALL_MVIEW_COMMENTS view was introduced in Oracle 10g
        if (is10_1 == null)
            is10_1 = configuredDialectIsNotFamilyAndSupports(asList(SQLDialect.DB2_10), () -> exists(COLUMNS.ROWBEGIN));

        return is10_1;
    }

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.DB2, new Settings().withFetchTrimmedCharValues(true));
    }

    @Override
    protected List<IndexDefinition> getIndexes0() throws SQLException {
        List<IndexDefinition> result = new ArrayList<>();

        Map<Record, Result<Record>> indexes = create()
            .select(
                trim(INDEXCOLUSE.indexes().TABSCHEMA),
                INDEXCOLUSE.indexes().TABNAME,
                INDEXCOLUSE.indexes().INDNAME,
                INDEXCOLUSE.indexes().UNIQUERULE,
                INDEXCOLUSE.COLNAME,
                INDEXCOLUSE.COLSEQ,
                INDEXCOLUSE.COLORDER)
            .from(INDEXCOLUSE)
            .where(INDEXCOLUSE.indexes().TABSCHEMA.in(getInputSchemata()))
            .and(getIncludeSystemIndexes()
                ? noCondition()
                : INDEXCOLUSE.indexes().SYSTEM_REQUIRED.eq(inline((short) 0)))
            .orderBy(
                trim(INDEXCOLUSE.indexes().TABSCHEMA),
                INDEXCOLUSE.indexes().TABNAME,
                INDEXCOLUSE.indexes().INDNAME,
                INDEXCOLUSE.COLSEQ)
            .fetchGroups(
                new Field[] {
                    trim(INDEXCOLUSE.indexes().TABSCHEMA),
                    INDEXCOLUSE.indexes().TABNAME,
                    INDEXCOLUSE.indexes().INDNAME,
                    INDEXCOLUSE.indexes().UNIQUERULE,
                },
                new Field[] {
                    INDEXCOLUSE.COLNAME,
                    INDEXCOLUSE.COLSEQ,
                    INDEXCOLUSE.COLORDER
                });

        indexLoop:
        for (Entry<Record, Result<Record>> entry : indexes.entrySet()) {
            final Record index = entry.getKey();
            final Result<Record> cols = entry.getValue();

            final SchemaDefinition tableSchema = getSchema(index.get(trim(INDEXCOLUSE.indexes().TABSCHEMA)));
            if (tableSchema == null)
                continue indexLoop;

            final String indexName = index.get(INDEXCOLUSE.indexes().INDNAME);
            final String tableName = index.get(INDEXCOLUSE.indexes().TABNAME);
            final TableDefinition table = getTable(tableSchema, tableName);
            if (table == null)
                continue indexLoop;

            final boolean unique = asList("P", "U").contains(index.get(INDEXCOLUSE.indexes().UNIQUERULE));

            // [#6310] [#6620] Function-based indexes are not yet supported
            // [#16237]        Alternatively, the column could be hidden or excluded
            for (Record column : cols)
                if (table.getColumn(column.get(INDEXCOLUSE.COLNAME)) == null)
                    continue indexLoop;

            result.add(new AbstractIndexDefinition(tableSchema, indexName, table, unique) {
                List<IndexColumnDefinition> indexColumns = new ArrayList<>();

                {
                    for (Record column : cols) {
                        indexColumns.add(new DefaultIndexColumnDefinition(
                            this,
                            table.getColumn(column.get(INDEXCOLUSE.COLNAME)),
                            "D".equals(column.get(INDEXCOLUSE.COLORDER)) ? SortOrder.DESC : SortOrder.ASC,
                            column.get(INDEXCOLUSE.COLSEQ, int.class)
                        ));
                    }
                }

                @Override
                protected List<IndexColumnDefinition> getIndexColumns0() {
                    return indexColumns;
                }
            });
        }

        return result;
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (Record record : primaryKeys(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(KEYCOLUSE.TABSCHEMA));
            String key = record.get(KEYCOLUSE.CONSTNAME);
            String tableName = record.get(KEYCOLUSE.TABNAME);
            String columnName = record.get(KEYCOLUSE.COLNAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addPrimaryKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        for (Record record : uniqueKeys(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(KEYCOLUSE.TABSCHEMA));
            String key = record.get(KEYCOLUSE.CONSTNAME);
            String tableName = record.get(KEYCOLUSE.TABNAME);
            String columnName = record.get(KEYCOLUSE.COLNAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addUniqueKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> primaryKeys(List<String> schemas) {
        return keys(schemas, "P");
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> uniqueKeys(List<String> schemas) {
        return keys(schemas, "U");
    }

    private ResultQuery<Record6<String, String, String, String, String, Integer>> keys(List<String> schemas, String constraintType) {
        return create().select(
                inline(null, VARCHAR).as("catalog"),
                trim(KEYCOLUSE.TABSCHEMA).as(KEYCOLUSE.TABSCHEMA),
                KEYCOLUSE.TABNAME,
                KEYCOLUSE.CONSTNAME,
                KEYCOLUSE.COLNAME,
                KEYCOLUSE.COLSEQ.coerce(INTEGER))
            .from(KEYCOLUSE)
            .where(KEYCOLUSE.TABSCHEMA.in(schemas))
            .and(KEYCOLUSE.tabconst().TYPE.eq(inline(constraintType)))
            .orderBy(
                KEYCOLUSE.TABSCHEMA.asc(),
                KEYCOLUSE.TABNAME.asc(),
                KEYCOLUSE.CONSTNAME.asc(),
                KEYCOLUSE.COLSEQ.asc());
    }

    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
        for (Record record : create().select(
                    REFERENCES.CONSTNAME,
                    trim(REFERENCES.TABSCHEMA),
                    REFERENCES.TABNAME,
                    REFERENCES.FK_COLNAMES,
                    REFERENCES.REFTABNAME,
                    REFERENCES.REFKEYNAME,
                    trim(REFERENCES.REFTABSCHEMA),

                    // [#9736] https://www.ibm.com/docs/en/db2/12.1?topic=views-syscatreferences
                    case_(REFERENCES.DELETERULE)
                        .when(inline("A"), ForeignKeyRule.NO_ACTION.name())
                        .when(inline("C"), ForeignKeyRule.CASCADE.name())
                        .when(inline("N"), ForeignKeyRule.SET_NULL.name())
                        .when(inline("R"), ForeignKeyRule.RESTRICT.name())
                        .as(REFERENCES.DELETERULE),
                    case_(REFERENCES.UPDATERULE)
                        .when(inline("A"), ForeignKeyRule.NO_ACTION.name())
                        .when(inline("C"), ForeignKeyRule.CASCADE.name())
                        .when(inline("N"), ForeignKeyRule.SET_NULL.name())
                        .when(inline("R"), ForeignKeyRule.RESTRICT.name())
                        .as(REFERENCES.UPDATERULE)
                )
                .from(REFERENCES)
                .where(REFERENCES.TABSCHEMA.in(getInputSchemata()))
                .orderBy(
                    REFERENCES.TABSCHEMA,
                    REFERENCES.TABNAME,
                    REFERENCES.CONSTNAME,
                    REFERENCES.FK_COLNAMES)
        ) {

            SchemaDefinition foreignKeySchema = getSchema(record.get(trim(REFERENCES.TABSCHEMA)));
            SchemaDefinition uniqueKeySchema = getSchema(record.get(trim(REFERENCES.REFTABSCHEMA)));

            String foreignKey = record.get(REFERENCES.CONSTNAME);
            String foreignKeyTableName = record.get(REFERENCES.TABNAME);
            String foreignKeyColumn = record.get(REFERENCES.FK_COLNAMES);
            String uniqueKey = record.get(REFERENCES.REFKEYNAME);
            String uniqueKeyTableName = record.get(REFERENCES.REFTABNAME);
            TableDefinition foreignKeyTable = getTable(foreignKeySchema, foreignKeyTableName);
            TableDefinition uniqueKeyTable = getTable(uniqueKeySchema, uniqueKeyTableName);
            ForeignKeyRule deleteRule = record.get(REFERENCES.DELETERULE, ForeignKeyRule.class);
            ForeignKeyRule updateRule = record.get(REFERENCES.UPDATERULE, ForeignKeyRule.class);

            if (foreignKeyTable != null && uniqueKeyTable != null) {
                /*
                 * If a foreign key consists of several columns, all the columns
                 * are contained in a single database column (delimited with
                 * space) here we split the combined string into individual
                 * columns
                 */
                String[] referencingColumnNames = foreignKeyColumn.trim().split("[ ]+");
                for (int i = 0; i < referencingColumnNames.length; i++) {
                    ColumnDefinition column = foreignKeyTable.getColumn(referencingColumnNames[i]);

                    relations.addForeignKey(
                        foreignKey,
                        foreignKeyTable,
                        column,
                        uniqueKey,
                        uniqueKeyTable,
                        true,
                        deleteRule,
                        updateRule
                    );
                }
            }
        }
    }

    static record CheckRecord (String schema, String table, String constraint, String text) {}

    @Override
    protected void loadCheckConstraints(DefaultRelations relations) throws SQLException {
        for (CheckRecord r : create()
            .select(
                CHECKS.TABSCHEMA,
                CHECKS.TABNAME,
                CHECKS.CONSTNAME,
                CHECKS.TEXT
            )
            .from(CHECKS)
            .where(CHECKS.TABSCHEMA.in(getInputSchemata()))
            .and(CHECKS.TYPE.eq(inline("C")))
            .orderBy(CHECKS.TABSCHEMA, CHECKS.TABNAME, CHECKS.CONSTNAME)
            .fetch(Records.mapping(CheckRecord::new))
        ) {
            SchemaDefinition schema = getSchema(r.schema);
            TableDefinition table = getTable(schema, r.table);

            if (table != null) {
                relations.addCheckConstraint(table, new DefaultCheckConstraintDefinition(
                    schema,
                    table,
                    r.constraint,
                    r.text
                ));
            }
        }
    }

    @Override
    protected List<CatalogDefinition> getCatalogs0() throws SQLException {
        List<CatalogDefinition> result = new ArrayList<>();
        result.add(new CatalogDefinition(this, "", ""));
        return result;
    }

    @Override
    protected List<SchemaDefinition> getSchemata0() throws SQLException {
        return
        create().select(trim(SCHEMATA.SCHEMANAME))
                .from(SCHEMATA)
                .fetch(mapping(s -> new SchemaDefinition(this, s, "")));
    }

    @Override
    public ResultQuery<Record4<String, String, String, String>> sources(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).as("catalog"),
                VIEWS.VIEWSCHEMA,
                VIEWS.VIEWNAME,
                VIEWS.TEXT)
            .from(VIEWS)
            .where(VIEWS.VIEWSCHEMA.in(schemas))
            .orderBy(
                VIEWS.VIEWSCHEMA,
                VIEWS.VIEWNAME);
    }

    @Override
    public ResultQuery<Record5<String, String, String, String, String>> comments(List<String> schemas) {
        Table<?> c =
            select(
                inline(null, VARCHAR).as("catalog"),
                trim(TABLES.TABSCHEMA).as(TABLES.TABSCHEMA),
                TABLES.TABNAME,
                inline(null, VARCHAR).as(COLUMNS.COLNAME),
                TABLES.REMARKS)
            .from(TABLES)
            .where(TABLES.REMARKS.isNotNull())
            .unionAll(
                select(
                    inline(null, VARCHAR),
                    COLUMNS.TABSCHEMA,
                    COLUMNS.TABNAME,
                    COLUMNS.COLNAME,
                    COLUMNS.REMARKS)
                .from(COLUMNS)
                .where(COLUMNS.REMARKS.isNotNull()))
            .asTable("c");

        return create()
            .select(
                c.field("catalog", VARCHAR),
                c.field(TABLES.TABSCHEMA),
                c.field(TABLES.TABNAME),
                c.field(COLUMNS.COLNAME),
                c.field(TABLES.REMARKS))
            .from(c)
            .where(c.field(TABLES.TABSCHEMA).in(schemas))
            .orderBy(1, 2, 3, 4);
    }

    @Override
    public ResultQuery<Record12<String, String, String, String, Integer, Integer, Long, Long, BigDecimal, BigDecimal, Boolean, Long>> sequences(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).as("catalog"),
                trim(SEQUENCES.SEQSCHEMA).as(SEQUENCES.SEQSCHEMA),
                SEQUENCES.SEQNAME,
                SEQUENCES.datatypes().TYPENAME,
                SEQUENCES.PRECISION.coerce(INTEGER),
                inline(null, INTEGER).as("numeric_scale"),
                nullif(SEQUENCES.START, one()).coerce(BIGINT).as(SEQUENCES.START),
                nullif(SEQUENCES.INCREMENT, one()).coerce(BIGINT).as(SEQUENCES.INCREMENT),
                nullif(SEQUENCES.MINVALUE, one()).coerce(NUMERIC).as(SEQUENCES.MINVALUE),
                nullif(SEQUENCES.MAXVALUE,
                    power(cast(inline(2), NUMERIC), SEQUENCES.datatypes().LENGTH.times(inline(8)).minus(inline(1))).minus(inline(1))).coerce(NUMERIC).as(SEQUENCES.MAXVALUE),
                SEQUENCES.CYCLE.coerce(BOOLEAN),
                nullif(SEQUENCES.CACHE, inline(DEFAULT_SEQUENCE_CACHE)).coerce(BIGINT).as(SEQUENCES.CACHE))
            .from(SEQUENCES)
            .where(SEQUENCES.SEQSCHEMA.in(schemas))
            .and(!getIncludeSystemSequences() ? SEQUENCES.SEQNAME.notLike(inline("SQL%")) : noCondition())
            .orderBy(
                SEQUENCES.SEQSCHEMA,
                SEQUENCES.SEQNAME);
    }

    @Override
    protected List<SequenceDefinition> getSequences0() throws SQLException {
        List<SequenceDefinition> result = new ArrayList<>();

        for (Record record : sequences(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(SEQUENCES.SEQSCHEMA));

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                this, schema,
                record.get(SEQUENCES.datatypes().TYPENAME),
                0,
                record.get(SEQUENCES.PRECISION),
                0,
                null,
                (String) null
            );

            result.add(new DefaultSequenceDefinition(
                schema,
                record.get(SEQUENCES.SEQNAME),
                type,
                null,
                record.get(SEQUENCES.START),
                record.get(SEQUENCES.INCREMENT),
                record.get(SEQUENCES.MINVALUE),
                record.get(SEQUENCES.MAXVALUE),
                record.get(SEQUENCES.CYCLE, Boolean.class),
                record.get(SEQUENCES.CACHE)
            ));
        }

        return result;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> enums(List<String> schemas) {
        return null;
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (Record record : create().select(
                trim(TABLES.TABSCHEMA).as(TABLES.TABSCHEMA),
                TABLES.TABNAME,
                TABLES.REMARKS,
                when(TABLES.TYPE.eq(inline("V")), inline(TableType.VIEW.name()))
                .when(TABLES.TYPE.eq(inline("G")), inline(TableType.GLOBAL_TEMPORARY.name()))
                .else_(inline(TableType.TABLE.name())).as("table_type"))
            .from(TABLES)
            .where(TABLES.TABSCHEMA.in(getInputSchemata()))

            // [#9574] Exclude aliases
            .and(TABLES.TYPE.ne(inline("A")))
            .orderBy(TABLES.TABSCHEMA, TABLES.TABNAME)
        ) {
            SchemaDefinition schema = getSchema(record.get(TABLES.TABSCHEMA));
            String name = record.get(TABLES.TABNAME);
            String comment = record.get(TABLES.REMARKS);
            TableType tableType = record.get("table_type", TableType.class);

            DB2TableDefinition table = new DB2TableDefinition(schema, name, comment, tableType, null);
            result.add(table);
        }

        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();

        Procedures p = PROCEDURES.as("p");
        Procparms pp = PROCPARMS.as("pp");
        Functions f = FUNCTIONS.as("f");
        Funcparms fp = FUNCPARMS.as("fp");

        for (Record record : create()
                .select().from(create()
                    .select(
                        trim(p.PROCSCHEMA).as("schema"),
                        p.PROCNAME.as("name"),
                        val(true).as("isProcedure"),
                        p.SPECIFICNAME.as("specificname"),

                        // Calculate overload index if applicable
                        overload(p.PROCSCHEMA, p.PROCNAME, field(
                            select(listAgg(pp.PARMNAME.concat(inline(" ")).concat(pp.TYPENAME), ",").withinGroupOrderBy(pp.ORDINAL))
                            .from(pp)
                            .where(pp.PROCSCHEMA.eq(p.PROCSCHEMA))
                            .and(pp.PROCNAME.eq(p.PROCNAME))
                            .and(pp.SPECIFICNAME.eq(p.SPECIFICNAME))
                        ))
                    )
                    .from(p)
                    .where(p.PROCSCHEMA.in(getInputSchemata()))

                    // [#8372] Exclude system-generated procedures
                    // https://www.ibm.com/support/knowledgecenter/en/SSEPGG_10.5.0/com.ibm.db2.luw.sql.ref.doc/doc/r0001045.html
                    .and(p.ORIGIN.ne(inline("S")))
                .unionAll(create()
                    .select(
                        trim(f.FUNCSCHEMA).as("schema"),
                        f.FUNCNAME.as("name"),
                        val(false).as("isProcedure"),
                        f.SPECIFICNAME.as("specificname"),

                        // Calculate overload index if applicable
                        overload(f.FUNCSCHEMA, f.FUNCNAME, field(
                            select(listAgg(fp.PARMNAME.concat(inline(" ")).concat(fp.TYPENAME), ",").withinGroupOrderBy(fp.ORDINAL))
                            .from(fp)
                            .where(fp.FUNCSCHEMA.eq(f.FUNCSCHEMA))
                            .and(fp.FUNCNAME.eq(f.FUNCNAME))
                            .and(fp.SPECIFICNAME.eq(f.SPECIFICNAME))
                        ))
                    )
                    .from(f)
                    .where(f.FUNCSCHEMA.in(getInputSchemata()))

                    // [#8372] Exclude system-generated functions (e.g. generated from array types)
                    // https://www.ibm.com/support/knowledgecenter/en/SSEPGG_10.5.0/com.ibm.db2.luw.sql.ref.doc/doc/r0001045.html
                    .and(f.ORIGIN.ne(inline("S")))))
                .orderBy(inline(2), inline(4))
                .fetch()) {

            result.add(new DB2RoutineDefinition(
                getSchema(record.get("schema", String.class)),
                record.get("name", String.class),
                null,
                record.get("isProcedure", boolean.class),
                record.get("specificname", String.class),
                record.get("overload", String.class)));
        }

        return result;
    }

    @Override
    protected List<PackageDefinition> getPackages0() throws SQLException {
        List<PackageDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<EnumDefinition> getEnums0() throws SQLException {
        List<EnumDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        List<DomainDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    public ResultQuery<Record14<String, String, String, String, String, String, Boolean, Boolean, Boolean, String, String, String, Integer, String>> triggers(List<String> schemas) {
        Triggers t = TRIGGERS.as("t");

        return create()
            .select(
                inline(null, VARCHAR).as("catalog_name"),
                t.TRIGSCHEMA,
                t.TRIGNAME,
                inline(null, VARCHAR).as("table_catalog_name"),
                t.TABSCHEMA,
                t.TABNAME,
                inline("Y").eq(t.EVENTINSERT).as("i"),
                inline("Y").eq(t.EVENTUPDATE).as("u"),
                inline("Y").eq(t.EVENTDELETE).as("d"),
                case_(t.GRANULARITY)
                    .when(inline("S"), inline(TriggerExecution.FOR_EACH_STATEMENT.name()))
                    .when(inline("R"), inline(TriggerExecution.FOR_EACH_ROW.name())).as(t.GRANULARITY),
                case_(t.TRIGTIME)
                    .when(inline("A"), inline(TriggerTime.AFTER.name()))
                    .when(inline("B"), inline(TriggerTime.BEFORE.name()))
                    .when(inline("I"), inline(TriggerTime.INSTEAD_OF.name())).as(t.TRIGTIME),
                inline(null, VARCHAR).as("action_condition"),
                inline(0).as("action_order"),
                t.TEXT
            )
            .from(t)
            .where(t.TRIGSCHEMA.in(schemas))
            .orderBy(
                t.TRIGSCHEMA,
                t.TRIGNAME);
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> synonyms(List<String> schemas) {
        Tables t = TABLES.as("t");

        return create()
            .select(
                inline(null, VARCHAR).as("catalog_name"),
                t.TABSCHEMA,
                t.TABNAME,
                inline(null, VARCHAR).as("base_catalog_name"),
                t.BASE_TABSCHEMA,
                t.BASE_TABNAME)
            .from(t)
            .where(t.TABSCHEMA.in(schemas))
            .and(t.TYPE.eq(inline("A")))
            .orderBy(t.TABSCHEMA, t.TABNAME)
        ;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> generators(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).as("catalog_name"),
                COLUMNS.TABSCHEMA,
                COLUMNS.TABNAME,
                COLUMNS.COLNAME,
                DSL.regexpReplaceAll(COLUMNS.TEXT, inline("AS \\((.*)\\)"), inline("\\1")),
                inline(GenerationOption.DEFAULT.name()))
            .from(COLUMNS)
            .where(COLUMNS.TABSCHEMA.in(schemas))
            .and(COLUMNS.GENERATED.eq(inline("A")))
            .orderBy(
                COLUMNS.TABSCHEMA,
                COLUMNS.TABNAME,
                COLUMNS.COLNO);
    }

    @Override
    protected List<XMLSchemaCollectionDefinition> getXMLSchemaCollections0() throws SQLException {
        List<XMLSchemaCollectionDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<UDTDefinition> getUDTs0() throws SQLException {
        List<UDTDefinition> result = new ArrayList<>();

        for (Record record : create().selectDistinct(
                    trim(DATATYPES.TYPESCHEMA),
                    DATATYPES.TYPENAME)
                .from(DATATYPES)
                .where(DATATYPES.TYPESCHEMA.in(getInputSchemata()))

                // [#8375] Exclude e.g. array types from being generated here
                // https://www.ibm.com/support/knowledgecenter/en/SS6NHC/com.ibm.swg.im.dashdb.sql.ref.doc/doc/r0001040.html
                // F = User-defined row type
                // R = User-defined structured type
                .and(DATATYPES.METATYPE.in(inline("F"), inline("R")))
                .orderBy(DATATYPES.TYPENAME))

            result.add(new DB2UDTDefinition(
                getSchema(record.get(trim(DATATYPES.TYPESCHEMA))),
                record.get(DATATYPES.TYPENAME),
                null));

        return result;
    }

    @Override
    protected List<ArrayDefinition> getArrays0() throws SQLException {
        List<ArrayDefinition> result = new ArrayList<>();

//        for (Record record : create()
//                .select(
//                    DATATYPES.TYPESCHEMA,
//                    DATATYPES.TYPENAME,
//                    DATATYPES.SOURCESCHEMA,
//                    DATATYPES.SOURCENAME,
//                    DATATYPES.LENGTH,
//                    DATATYPES.SCALE)
//                .from(DATATYPES.DATATYPES)
//                .where(DATATYPES.METATYPE.eq(inline("A")))
//                .and(DATATYPES.TYPESCHEMA.in(getInputSchemata()))
//                .orderBy(
//                    DATATYPES.TYPESCHEMA,
//                    DATATYPES.TYPENAME)) {
//
//            SchemaDefinition schema = getSchema(record.get(DATATYPES.TYPESCHEMA));
//            String name = record.get(DATATYPES.TYPENAME);
//
//            if (schema != null && name != null) {
//                String dataType = record.get(DATATYPES.SOURCENAME);
//
//                int length = record.get(DATATYPES.LENGTH, int.class).intValue();
//                int scale = record.get(DATATYPES.SCALE, int.class).intValue();
//
//                DefaultDataTypeDefinition type = new DefaultDataTypeDefinition(this, schema, dataType, length, length, scale, null, (String) null, name);
//                DefaultArrayDefinition array = new DefaultArrayDefinition(schema, null, name, type);
//
//                result.add(array);
//            }
//        }

        return result;
    }
}
