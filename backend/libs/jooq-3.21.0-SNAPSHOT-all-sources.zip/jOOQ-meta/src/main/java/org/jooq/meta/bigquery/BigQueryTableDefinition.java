/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta.bigquery;

import static org.jooq.impl.DSL.inline;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.Record;
import org.jooq.TableOptions.TableType;
import org.jooq.meta.AbstractTableDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultColumnDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.SchemaDefinition;

/**
 * @author Lukas Eder
 */
public class BigQueryTableDefinition extends AbstractTableDefinition {

    public BigQueryTableDefinition(SchemaDefinition schema, String name, String comment, TableType tableType, String source) {
        super(schema, name, comment, tableType, source);
    }

	@Override
	public List<ColumnDefinition> getElements0() throws SQLException {
		List<ColumnDefinition> result = new ArrayList<>();

        for (Record record : create().fetch(
            """
            SELECT
              c.COLUMN_NAME,
              c.ORDINAL_POSITION,
              c.IS_NULLABLE,
              c.DATA_TYPE,
              TRIM(p.DESCRIPTION, '"') AS COMMENT
            FROM {0}.INFORMATION_SCHEMA.COLUMNS c
            LEFT JOIN {0}.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS p
            ON c.TABLE_CATALOG = p.TABLE_CATALOG
            AND c.TABLE_SCHEMA = p.TABLE_SCHEMA
            AND c.TABLE_NAME = p.TABLE_NAME
            AND c.COLUMN_NAME = p.COLUMN_NAME
            AND p.COLUMN_nAmE = p.FIELD_PATH
            AND p.DESCRIPTION IS NOT NULL
            WHERE c.TABLE_SCHEMA = {1}
            AND c.TABLE_NAME = {2}
            ORDER BY c.TABLE_NAME, c.ORDINAL_POSITION
            """,

            // [#15472] Qualify the INFORMATION_SCHEMA with the dataset, in case it isn't the
            //          JDBC URL's DefaultDataset.
            getSchema().getQualifiedInputNamePart(),

            // Using bind variables seems to cause trouble finding the data set
            inline(getSchema().getName()),
            inline(getInputName())
        )) {
            DataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get("DATA_TYPE", String.class),
                0,
                0,
                0,
                record.get("IS_NULLABLE", boolean.class),
                (String) null
            );

			result.add(new DefaultColumnDefinition(
			    getDatabase().getTable(getSchema(), getName()),
			    record.get("COLUMN_NAME", String.class),
                record.get("ORDINAL_POSITION", int.class),
                type,
			    false,
			    record.get("COMMENT", String.class)
		    ));
		}

		return result;
	}
}
