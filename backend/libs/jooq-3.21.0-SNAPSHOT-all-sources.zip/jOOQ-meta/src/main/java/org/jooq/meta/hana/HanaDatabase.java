/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta.hana;

import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.lower;
import static org.jooq.impl.DSL.name;
import static org.jooq.impl.DSL.nullif;
import static org.jooq.impl.DSL.one;
import static org.jooq.impl.DSL.replace;
import static org.jooq.impl.DSL.row;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.when;
import static org.jooq.impl.SQLDataType.BIGINT;
import static org.jooq.impl.SQLDataType.DECIMAL;
import static org.jooq.impl.SQLDataType.VARCHAR;
import static org.jooq.meta.hana.sys.Tables.CONSTRAINTS;
import static org.jooq.meta.hana.sys.Tables.ELEMENT_TYPES;
import static org.jooq.meta.hana.sys.Tables.FUNCTIONS;
import static org.jooq.meta.hana.sys.Tables.FUNCTION_PARAMETERS;
import static org.jooq.meta.hana.sys.Tables.*;
import static org.jooq.meta.hana.sys.Tables.REFERENTIAL_CONSTRAINTS;
import static org.jooq.meta.hana.sys.Tables.SCHEMAS;
import static org.jooq.meta.hana.sys.Tables.SEQUENCES;
import static org.jooq.meta.hana.sys.Tables.TABLES;
import static org.jooq.meta.hana.sys.Tables.VIEWS;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Record12;
import org.jooq.Record14;
import org.jooq.Record4;
import org.jooq.Record5;
import org.jooq.Record6;
import org.jooq.Result;
import org.jooq.ResultQuery;
import org.jooq.Row2;
import org.jooq.SQLDialect;
import org.jooq.TableField;
import org.jooq.TableOptions.TableType;
import org.jooq.impl.DSL;
import org.jooq.impl.QOM.ForeignKeyRule;
import org.jooq.impl.SQLDataType;
import org.jooq.meta.AbstractDatabase;
import org.jooq.meta.ArrayDefinition;
import org.jooq.meta.CatalogDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultCheckConstraintDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.DefaultRelations;
import org.jooq.meta.DefaultSequenceDefinition;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.EnumDefinition;
import org.jooq.meta.PackageDefinition;
import org.jooq.meta.ResultQueryDatabase;
import org.jooq.meta.RoutineDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.SequenceDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.UDTDefinition;
import org.jooq.meta.XMLSchemaCollectionDefinition;
import org.jooq.meta.hana.sys.tables.Constraints;
import org.jooq.meta.hana.sys.tables.ElementTypes;
import org.jooq.meta.hana.sys.tables.FunctionParameters;
import org.jooq.meta.hana.sys.tables.Functions;
import org.jooq.meta.hana.sys.tables.Procedures;
import org.jooq.meta.hana.sys.tables.ReferentialConstraints;

/**
 * The Hana database
 *
 * @author Lukas Eder
 */
public class HanaDatabase extends AbstractDatabase implements ResultQueryDatabase {

    private static final long DEFAULT_SEQUENCE_CACHE    = 1L;
    private static final long DEFAULT_SEQUENCE_MAXVALUE = Long.MAX_VALUE;

    @Override
    protected DSLContext create0() {
        return DSL.using(getConnection(), SQLDialect.HANA);
    }

    @Override
    protected void loadPrimaryKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys("TRUE")) {
            SchemaDefinition schema = getSchema(record.get(CONSTRAINTS.SCHEMA_NAME));
            String key = record.get(CONSTRAINTS.CONSTRAINT_NAME);
            String tableName = record.get(CONSTRAINTS.TABLE_NAME);
            String columnName = record.get(CONSTRAINTS.COLUMN_NAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addPrimaryKey(key, table, table.getColumn(columnName));
        }
    }

    @Override
    protected void loadUniqueKeys(DefaultRelations relations) throws SQLException {
        for (Record record : fetchKeys("FALSE")) {
            SchemaDefinition schema = getSchema(record.get(CONSTRAINTS.SCHEMA_NAME));
            String key = record.get(CONSTRAINTS.CONSTRAINT_NAME);
            String tableName = record.get(CONSTRAINTS.TABLE_NAME);
            String columnName = record.get(CONSTRAINTS.COLUMN_NAME);

            TableDefinition table = getTable(schema, tableName);
            if (table != null)
                relations.addUniqueKey(key, table, table.getColumn(columnName));
        }
    }

    private Result<Record4<String, String, String, String>> fetchKeys(String isPrimaryKey) {
        Constraints c = CONSTRAINTS;

        return create()
            .select(
                c.SCHEMA_NAME,
                c.CONSTRAINT_NAME,
                c.TABLE_NAME,
                c.COLUMN_NAME)
            .from(c)
            .where(c.IS_PRIMARY_KEY.eq(isPrimaryKey))
            .and(c.IS_UNIQUE_KEY.eq("TRUE"))
            .and(c.SCHEMA_NAME.in(getInputSchemata()))
            .orderBy(
                c.SCHEMA_NAME.asc(),
                c.TABLE_NAME.asc(),
                c.CONSTRAINT_NAME.asc(),
                c.POSITION.asc())
            .fetch();
    }
    @Override
    protected void loadForeignKeys(DefaultRelations relations) throws SQLException {
        ReferentialConstraints rc = REFERENTIAL_CONSTRAINTS;
        Constraints c = CONSTRAINTS;

        for (Record record : create()
            .select(
                rc.SCHEMA_NAME,
                rc.TABLE_NAME,
                rc.COLUMN_NAME,
                rc.CONSTRAINT_NAME,
                rc.REFERENCED_SCHEMA_NAME,
                rc.REFERENCED_CONSTRAINT_NAME,
                rc.REFERENCED_TABLE_NAME,
                rc.REFERENCED_COLUMN_NAME,
                replace(rc.DELETE_RULE, inline(" "), inline("_")).as(rc.DELETE_RULE),
                replace(rc.UPDATE_RULE, inline(" "), inline("_")).as(rc.UPDATE_RULE)
            )
            .from(rc)
            .join(c)
            .on(rc.REFERENCED_SCHEMA_NAME.eq(c.SCHEMA_NAME))
            .and(rc.REFERENCED_CONSTRAINT_NAME.eq(c.CONSTRAINT_NAME))
            .and(rc.REFERENCED_TABLE_NAME.eq(c.TABLE_NAME))
            .where(rc.SCHEMA_NAME.in(getInputSchemata()))
            .orderBy(
                rc.SCHEMA_NAME,
                rc.TABLE_NAME,
                rc.CONSTRAINT_NAME,
                rc.POSITION
            )) {

            SchemaDefinition foreignKeySchema = getSchema(record.get(rc.SCHEMA_NAME));
            SchemaDefinition uniqueKeySchema = getSchema(record.get(rc.REFERENCED_SCHEMA_NAME));

            String foreignKey = record.get(rc.CONSTRAINT_NAME);
            String foreignKeyTableName = record.get(rc.TABLE_NAME);
            String foreignKeyColumn = record.get(rc.COLUMN_NAME);
            String uniqueKey = record.get(rc.REFERENCED_CONSTRAINT_NAME);
            String uniqueKeyTableName = record.get(rc.REFERENCED_TABLE_NAME);
            String uniqueKeyColumn = record.get(rc.REFERENCED_COLUMN_NAME);
            ForeignKeyRule deleteRule = record.get(rc.DELETE_RULE, ForeignKeyRule.class);
            ForeignKeyRule updateRule = record.get(rc.UPDATE_RULE, ForeignKeyRule.class);

            TableDefinition foreignKeyTable = getTable(foreignKeySchema, foreignKeyTableName);
            TableDefinition uniqueKeyTable = getTable(uniqueKeySchema, uniqueKeyTableName);

            if (foreignKeyTable != null && uniqueKeyTable != null)
                relations.addForeignKey(
                    foreignKey,
                    foreignKeyTable,
                    foreignKeyTable.getColumn(foreignKeyColumn),
                    uniqueKey,
                    uniqueKeyTable,
                    uniqueKeyTable.getColumn(uniqueKeyColumn),
                    true,
                    deleteRule,
                    updateRule
                );
        }
    }

    @Override
    protected void loadCheckConstraints(DefaultRelations relations) throws SQLException {
        Constraints c = CONSTRAINTS.as("c");

        for (Record record : create()
                .select(
                    c.SCHEMA_NAME,
                    c.TABLE_NAME,
                    c.CONSTRAINT_NAME,
                    c.CHECK_CONDITION
                 )
                .from(c)
                .where(c.SCHEMA_NAME.in(getInputSchemata()))
                .and(c.CHECK_CONDITION.isNotNull())
                .orderBy(c.SCHEMA_NAME, c.TABLE_NAME, c.CONSTRAINT_NAME)) {

            SchemaDefinition schema = getSchema(record.get(c.SCHEMA_NAME));
            TableDefinition table = getTable(schema, record.get(c.TABLE_NAME));

            if (table != null) {
                relations.addCheckConstraint(table, new DefaultCheckConstraintDefinition(
                    schema,
                    table,
                    record.get(c.CONSTRAINT_NAME),
                    record.get(c.CHECK_CONDITION)
                ));
            }
        }
    }

    @Override
    protected List<CatalogDefinition> getCatalogs0() throws SQLException {
        List<CatalogDefinition> result = new ArrayList<>();
        result.add(new CatalogDefinition(this, "", ""));
        return result;
    }

    @Override
    protected List<SchemaDefinition> getSchemata0() throws SQLException {
        return
        create().select(SCHEMAS.SCHEMA_NAME)
                .from(SCHEMAS)
                .collect(mapping(r -> new SchemaDefinition(this, r.value1(), ""), toList()));
    }

    @Override
    public ResultQuery<Record4<String, String, String, String>> sources(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).as("catalog"),
                VIEWS.SCHEMA_NAME,
                VIEWS.VIEW_NAME,
                VIEWS.DEFINITION)
            .from(VIEWS)
            .where(VIEWS.SCHEMA_NAME.in(schemas))
            .orderBy(
                VIEWS.SCHEMA_NAME,
                VIEWS.VIEW_NAME);
    }

    @Override
    public ResultQuery<Record5<String, String, String, String, String>> comments(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record12<String, String, String, String, Integer, Integer, Long, Long, BigDecimal, BigDecimal, Boolean, Long>> sequences(List<String> schemas) {
        Field<Long> min = SEQUENCES.MIN_VALUE.coerce(BIGINT);
        Field<Long> max = SEQUENCES.MAX_VALUE.coerce(BIGINT);

        return create()
            .select(
                inline(null, VARCHAR).as("catalog"),
                SEQUENCES.SCHEMA_NAME,
                SEQUENCES.SEQUENCE_NAME,
                when(contains(row(min, max), row(inline(0L), inline(255L))), inline("TINYINT"))
                    .when(contains(row(min, max), row(inline((long) Short.MIN_VALUE), inline((long) Short.MAX_VALUE))), inline("SMALLINT"))
                    .when(contains(row(min, max), row(inline((long) Integer.MIN_VALUE), inline((long) Integer.MAX_VALUE))), inline("INTEGER"))
                    .when(contains(row(min, max), row(inline(Long.MIN_VALUE), inline(Long.MAX_VALUE))), inline("BIGINT"))
                    .else_(inline("DECIMAL"))
                    .as("type_name"),
                inline(0).as("precision"),
                inline(0).as("scale"),
                nullif(SEQUENCES.START_NUMBER, one()).coerce(BIGINT).as(SEQUENCES.START_NUMBER),
                nullif(SEQUENCES.INCREMENT_BY, one()).coerce(BIGINT).as(SEQUENCES.INCREMENT_BY),
                nullif(SEQUENCES.MIN_VALUE, one()).coerce(DECIMAL).as(SEQUENCES.MIN_VALUE),
                nullif(SEQUENCES.MAX_VALUE, inline(DEFAULT_SEQUENCE_MAXVALUE)).coerce(DECIMAL).as(SEQUENCES.MAX_VALUE),
                SEQUENCES.IS_CYCLED.eq(inline("TRUE")).as(SEQUENCES.IS_CYCLED),
                nullif(SEQUENCES.CACHE_SIZE, inline(DEFAULT_SEQUENCE_CACHE)).coerce(BIGINT).as(SEQUENCES.CACHE_SIZE)
            )
            .from(SEQUENCES)
            .where(SEQUENCES.SCHEMA_NAME.in(schemas))
            .orderBy(
                SEQUENCES.SCHEMA_NAME,
                SEQUENCES.SEQUENCE_NAME);
    }

    // [#16649] TODO: Move these into the core library
    static final <T> Condition contains(Row2<T, T> r1, Row2<T, T> r2) {
        return r1.field1().between(r2.field1(), r2.field2()).and(r1.field2().between(r2.field1(), r2.field2()));
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> enums(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> primaryKeys(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, Integer>> uniqueKeys(List<String> schemas) {
        return null;
    }

    @Override
    protected List<SequenceDefinition> getSequences0() throws SQLException {
        List<SequenceDefinition> result = new ArrayList<>();

        for (Record record : sequences(getInputSchemata())) {
            SchemaDefinition schema = getSchema(record.get(SEQUENCES.SCHEMA_NAME));

            DataTypeDefinition type = new DefaultDataTypeDefinition(
                this,
                schema,
                record.get("type_name", String.class)
            );

            result.add(new DefaultSequenceDefinition(
                schema,
                record.get(SEQUENCES.SEQUENCE_NAME),
                type,
                null,
                record.get(SEQUENCES.START_NUMBER),
                record.get(SEQUENCES.INCREMENT_BY),
                record.get(SEQUENCES.MIN_VALUE),
                record.get(SEQUENCES.MAX_VALUE),
                record.get(SEQUENCES.IS_CYCLED, Boolean.class),
                record.get(SEQUENCES.CACHE_SIZE)
            ));
        }

        return result;
    }

    @Override
    protected List<TableDefinition> getTables0() throws SQLException {
        List<TableDefinition> result = new ArrayList<>();

        for (Record record : create()
                .select(
                    TABLES.SCHEMA_NAME,
                    TABLES.TABLE_NAME,
                    TABLES.COMMENTS,
                    when(TABLES.TEMPORARY_TABLE_TYPE.eq(inline("GLOBAL")), inline(TableType.GLOBAL_TEMPORARY.name()))
                        .else_(inline(TableType.TABLE.name()))
                        .as("table_type"),
                    inline(null, String.class).as(VIEWS.DEFINITION))
                .from(TABLES)
                .where(TABLES.SCHEMA_NAME.in(getInputSchemata()))

                // CREATE TYPE .. AS TABLE generates such USER_DEFINED_TYPEs
                .and(TABLES.IS_USER_DEFINED_TYPE.ne(inline("TRUE")))
                .unionAll(
                 select(
                    VIEWS.SCHEMA_NAME,
                    VIEWS.VIEW_NAME,
                    VIEWS.COMMENTS,
                    inline(TableType.VIEW.name()).as("table_type"),
                    when(lower(VIEWS.DEFINITION).like(inline("create%")), VIEWS.DEFINITION)
                        .else_(prependCreateView(VIEWS.VIEW_NAME, VIEWS.DEFINITION, '"')).as(VIEWS.DEFINITION))
                .from(VIEWS)
                .where(VIEWS.SCHEMA_NAME.in(getInputSchemata())))
                .orderBy(1, 2)) {

            SchemaDefinition schema = getSchema(record.get(TABLES.SCHEMA_NAME));
            String name = record.get(TABLES.TABLE_NAME);
            TableType tableType = record.get("table_type", TableType.class);
            String source = record.get(VIEWS.DEFINITION);
            String comment = record.get(TABLES.COMMENTS);

            result.add(new HanaTableDefinition(schema, name, comment, tableType, source));
        }

        return result;
    }

    @Override
    protected List<EnumDefinition> getEnums0() throws SQLException {
        List<EnumDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        List<DomainDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    public ResultQuery<Record14<String, String, String, String, String, String, Boolean, Boolean, Boolean, String, String, String, Integer, String>> triggers(List<String> schemas) {
        return null;
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> synonyms(List<String> schemas) {
        return create()
            .select(
                inline(null, VARCHAR).as("synonym_catalog"),
                SYNONYMS.SCHEMA_NAME,
                SYNONYMS.SYNONYM_NAME,
                inline(null, VARCHAR).as("table_catalog"),
                SYNONYMS.OBJECT_SCHEMA,
                SYNONYMS.OBJECT_NAME)
            .from(SYNONYMS)
            .where(SYNONYMS.SCHEMA_NAME.in(schemas))
            .and(SYNONYMS.OBJECT_TYPE.in(inline("TABLE"), inline("VIEW")))
            .orderBy(SYNONYMS.SCHEMA_NAME, SYNONYMS.SYNONYM_NAME);
    }

    @Override
    public ResultQuery<Record6<String, String, String, String, String, String>> generators(List<String> schemas) {
        return null;
    }

    @Override
    protected List<XMLSchemaCollectionDefinition> getXMLSchemaCollections0() throws SQLException {
        List<XMLSchemaCollectionDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<UDTDefinition> getUDTs0() throws SQLException {
        List<UDTDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<ArrayDefinition> getArrays0() throws SQLException {
        List<ArrayDefinition> result = new ArrayList<>();
        return result;
    }

    @Override
    protected List<RoutineDefinition> getRoutines0() throws SQLException {
        List<RoutineDefinition> result = new ArrayList<>();

        Procedures p = PROCEDURES;
        Functions f = FUNCTIONS;
        FunctionParameters fp = FUNCTION_PARAMETERS;
        ElementTypes et = ELEMENT_TYPES;

        for (Record record : create()
            .select(
                p.SCHEMA_NAME,
                p.PROCEDURE_NAME,
                p.PROCEDURE_OID,
                inline(null, String.class).as(fp.DATA_TYPE_NAME),
                inline(null, Integer.class).as(fp.LENGTH),
                inline(null, Integer.class).as(fp.SCALE))
            .from(p)
            .where(p.SCHEMA_NAME.in(getInputSchemata()))
            .unionAll(
                 select(
                    f.SCHEMA_NAME,
                    f.FUNCTION_NAME,
                    f.FUNCTION_OID,
                    when(et.DATA_TYPE_NAME.isNotNull(), et.DATA_TYPE_NAME.concat(inline(" ARRAY")))
                        .else_(fp.DATA_TYPE_NAME).as(fp.DATA_TYPE_NAME),
                    fp.LENGTH,
                    fp.SCALE)
                .from(f)
                    .leftOuterJoin(fp)
                        .on(f.FUNCTION_OID.eq(fp.FUNCTION_OID))
                        .and(fp.PARAMETER_TYPE.eq(inline("RETURN")))
                        .and(f.RETURN_VALUE_COUNT.eq(inline(1)))
                    .leftOuterJoin(et)
                        .on(et.SCHEMA_NAME.eq(fp.SCHEMA_NAME))
                        .and(et.OBJECT_NAME.eq(fp.FUNCTION_NAME))
                        .and(et.OBJECT_OID.eq(fp.FUNCTION_OID))
                        .and(et.ELEMENT_NAME.eq(fp.PARAMETER_NAME))
                .where(f.SCHEMA_NAME.in(getInputSchemata()))
            )
            .orderBy(
                field(name(p.SCHEMA_NAME.getName())),
                field(name(p.PROCEDURE_NAME.getName()))
        )) {

            result.add(new HanaRoutineDefinition(
                getSchema(record.get(p.SCHEMA_NAME)),
                record.get(p.PROCEDURE_NAME),
                record.get(p.PROCEDURE_OID),
                record.get(fp.DATA_TYPE_NAME),
                record.get(fp.LENGTH),
                record.get(fp.SCALE)
            ));
        }

        return result;
    }

    @Override
    protected List<PackageDefinition> getPackages0() throws SQLException {
        List<PackageDefinition> result = new ArrayList<>();
        return result;
    }
}
