/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */

package org.jooq.meta.cockroachdb;

import static org.jooq.impl.DSL.any;
import static org.jooq.impl.DSL.arrayGet;
import static org.jooq.impl.DSL.cast;
import static org.jooq.impl.DSL.condition;
import static org.jooq.impl.DSL.currentCatalog;
import static org.jooq.impl.DSL.field;
import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.not;
import static org.jooq.impl.DSL.nullif;
import static org.jooq.impl.DSL.nvl;
import static org.jooq.impl.DSL.regexpReplaceFirst;
import static org.jooq.impl.DSL.select;
import static org.jooq.impl.DSL.upper;
import static org.jooq.impl.DSL.when;
import static org.jooq.impl.SQLDataType.BIGINT;
import static org.jooq.impl.SQLDataType.INTEGER;
import static org.jooq.impl.SQLDataType.VARCHAR;
import static org.jooq.meta.postgres.information_schema.Tables.ATTRIBUTES;
import static org.jooq.meta.postgres.information_schema.Tables.COLUMNS;
import static org.jooq.meta.postgres.information_schema.Tables.PARAMETERS;
import static org.jooq.meta.postgres.information_schema.Tables.ROUTINES;
import static org.jooq.meta.postgres.pg_catalog.Tables.PG_ATTRDEF;
import static org.jooq.meta.postgres.pg_catalog.Tables.PG_ATTRIBUTE;
import static org.jooq.meta.postgres.pg_catalog.Tables.PG_PROC;
import static org.jooq.meta.postgres.pg_catalog.Tables.PG_TYPE;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.ExecuteListener;
import org.jooq.Field;
import org.jooq.Query;
import org.jooq.QueryPart;
import org.jooq.Record;
import org.jooq.Result;
import org.jooq.SQLDialect;
import org.jooq.SortOrder;
import org.jooq.Table;
import org.jooq.TableField;
import org.jooq.impl.DSL;
import org.jooq.impl.QOM.Aliasable;
import org.jooq.impl.TableImpl;
import org.jooq.meta.AbstractIndexDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DefaultIndexColumnDefinition;
import org.jooq.meta.DomainDefinition;
import org.jooq.meta.IndexColumnDefinition;
import org.jooq.meta.IndexDefinition;
import org.jooq.meta.SchemaDefinition;
import org.jooq.meta.TableDefinition;
import org.jooq.meta.TriggerDefinition;
import org.jooq.meta.UniqueKeyDefinition;
import org.jooq.meta.postgres.PostgresDatabase;
import org.jooq.meta.postgres.information_schema.tables.Parameters;
import org.jooq.meta.postgres.information_schema.tables.Routines;
import org.jooq.meta.postgres.pg_catalog.tables.PgAttrdef;
import org.jooq.meta.postgres.pg_catalog.tables.PgAttribute;
import org.jooq.meta.postgres.pg_catalog.tables.PgProc;
import org.jooq.meta.postgres.pg_catalog.tables.PgType;

/**
 * @author Lukas Eder
 */
public class CockroachDBDatabase extends PostgresDatabase {

    @Override
    protected DSLContext create0() {
        DSLContext ctx = DSL.using(getConnection(), SQLDialect.COCKROACHDB);

        ctx.configuration().set(ExecuteListener.onRenderStart(e -> {

            // Native support not yet available:
            // - https://github.com/cockroachdb/cockroach/issues/104083
            // - https://github.com/postgres/postgres/blob/master/src/backend/catalog/information_schema.sql
            PgProc p = PG_PROC.as("p");

            Table<?> routines =
                select(
                    currentCatalog().as(ROUTINES.SPECIFIC_CATALOG),
                    p.pgNamespace().NSPNAME.as(ROUTINES.SPECIFIC_SCHEMA),
                    p.PRONAME.concat("_").concat(p.OID).as(ROUTINES.SPECIFIC_NAME),
                    currentCatalog().as(ROUTINES.ROUTINE_CATALOG),
                    p.pgNamespace().NSPNAME.as(ROUTINES.ROUTINE_SCHEMA),
                    p.PRONAME.as(ROUTINES.ROUTINE_NAME),
                    inline("f").as(ROUTINES.ROUTINE_TYPE),
                    when(p.PROKIND.eq(inline("p")), inline((String) null))
                        .when(p.pgType().TYPELEM.ne(inline(0L)).and(p.pgType().TYPLEN.eq(inline((short) -1))), inline("ARRAY"))
                        .when(p.pgType().pgNamespace().NSPNAME.eq(inline("pg_catalog")), formatType(p.pgType()))
                        .else_(inline("USER-DEFINED")).as(ROUTINES.DATA_TYPE),
                    p.pgType().TYPNAME.as(ROUTINES.TYPE_UDT_NAME),
                    currentCatalog().as(ROUTINES.TYPE_UDT_CATALOG),
                    p.pgType().pgNamespace().NSPNAME.as(ROUTINES.TYPE_UDT_SCHEMA),
                    inline((String) null).as(ROUTINES.CHARACTER_MAXIMUM_LENGTH),
                    inline((String) null).as(ROUTINES.NUMERIC_PRECISION),
                    inline((String) null).as(ROUTINES.NUMERIC_SCALE)
                )
                .from(p)
                .asTable(ROUTINES);

            Table<?> s = select(
                field("(information_schema._pg_expandarray(coalesce({0}, {1}::oid[]))).x", BIGINT, p.PROALLARGTYPES, p.PROARGTYPES).as("x"),
                field("(information_schema._pg_expandarray(coalesce({0}, {1}::oid[]))).n", INTEGER, p.PROALLARGTYPES, p.PROARGTYPES).as("n")
            ).asTable("s");

            Field<Long> sx = s.field("x", BIGINT);
            Field<Integer> sn = s.field("n", INTEGER);
            Table<?> parameters =
                select(
                    currentCatalog().as(PARAMETERS.SPECIFIC_CATALOG),
                    p.pgNamespace().NSPNAME.as(PARAMETERS.SPECIFIC_SCHEMA),
                    p.PRONAME.concat("_").concat(p.OID).as(PARAMETERS.SPECIFIC_NAME),
                    nullif(arrayGet(p.PROARGNAMES, sn), inline("")).as(PARAMETERS.PARAMETER_NAME),
                    sn.as(PARAMETERS.ORDINAL_POSITION),
                    when(PG_TYPE.TYPELEM.ne(inline(0L)).and(PG_TYPE.TYPLEN.eq(inline((short) -1))), inline("ARRAY"))
                        .when(PG_TYPE.pgNamespace().NSPNAME.eq(inline("pg_catalog")), formatType(PG_TYPE))
                        .as(PARAMETERS.DATA_TYPE),
                    currentCatalog().as(PARAMETERS.UDT_CATALOG),
                    PG_TYPE.pgNamespace().NSPNAME.as(PARAMETERS.UDT_SCHEMA),
                    PG_TYPE.TYPNAME.as(PARAMETERS.UDT_NAME),
                    inline((String) null).as(PARAMETERS.CHARACTER_MAXIMUM_LENGTH),
                    inline((String) null).as(PARAMETERS.NUMERIC_PRECISION),
                    inline((String) null).as(PARAMETERS.NUMERIC_SCALE),
                    inline("IN").as(PARAMETERS.PARAMETER_MODE),
                    inline((String) null).as(PARAMETERS.PARAMETER_DEFAULT)
                )
                .from(p)
                .crossApply(s)
                .join(PG_TYPE).on(PG_TYPE.OID.eq(sx))
                .asTable(PARAMETERS);

            // [#15145] It appears that PG_ATTRIBUTE isn't populated with RELKIND = 'c' yet:
            //          https://github.com/cockroachdb/cockroach/issues/109603
            PgAttribute a = PG_ATTRIBUTE.as("a");
            PgAttrdef ad = PG_ATTRDEF.as("ad");

            Table<?> attributes =
                select(
                    currentCatalog().as(ATTRIBUTES.UDT_CATALOG),
                    a.pgClass().pgNamespace().NSPNAME.as(ATTRIBUTES.UDT_SCHEMA),
                    a.pgClass().RELNAME.as(ATTRIBUTES.UDT_NAME),
                    a.ATTNAME.as(ATTRIBUTES.ATTRIBUTE_NAME),
                    a.ATTNUM.as(ATTRIBUTES.ORDINAL_POSITION),
                    field("(pg_get_expr({0}, {1}))::varchar", ATTRIBUTES.ATTRIBUTE_DEFAULT.getDataType(), ad.ADBIN, ad.ADRELID).as(ATTRIBUTES.ATTRIBUTE_DEFAULT),
                    when(condition(a.ATTNOTNULL).or(a.pgType().TYPTYPE.eq(inline("d")).and(a.pgType().TYPNOTNULL)), inline("NO"))
                        .else_(inline("YES")).as(ATTRIBUTES.IS_NULLABLE),
                    when(a.pgType().TYPELEM.ne(inline(0L)).and(a.pgType().TYPLEN.eq(inline((short) -1))), inline("ARRAY"))
                        .when(a.pgType().pgNamespace().NSPNAME.eq(inline("pg_catalog")), formatType(a.pgType()))
                        .else_(inline("USER-DEFINED")).as(ATTRIBUTES.DATA_TYPE),
                    // TODO: _pg_char_max_length(_pg_truetypid(a, t), _pg_truetypmod(a, t))
                    inline((Integer) null).as(ATTRIBUTES.CHARACTER_MAXIMUM_LENGTH),

                    // TODO: _pg_numeric_precision(_pg_truetypid(a, t), _pg_truetypmod(a, t))
                    inline((Integer) null).as(ATTRIBUTES.NUMERIC_PRECISION),

                    // TODO: _pg_numeric_scale(_pg_truetypid(a, t), _pg_truetypmod(a, t))
                    inline((Integer) null).as(ATTRIBUTES.NUMERIC_SCALE),
                    currentCatalog().as(ATTRIBUTES.ATTRIBUTE_UDT_CATALOG),
                    a.pgType().pgNamespace().NSPNAME.as(ATTRIBUTES.ATTRIBUTE_UDT_SCHEMA),
                    a.pgType().TYPNAME.as(ATTRIBUTES.ATTRIBUTE_UDT_NAME)
                )
                .from(a)
                    .leftJoin(ad)
                        .on(a.ATTRELID.eq(ad.ADRELID))
                        .and(a.ATTNUM.eq(ad.ADNUM))
                .where(a.ATTNUM.gt(inline((short) 0)))
                .andNot(a.ATTISDROPPED)
                .and(a.pgClass().RELKIND.in(inline("c")))
                .asTable(ATTRIBUTES);

            e.query((Query) e.query().$replace(q -> {
                if (q instanceof TableImpl<?> ti) {
                    Table<?> x = replaceTables(ti, routines, ROUTINES, t -> routines, ti);
                    if (x != ti)
                        return x;

                    x = replaceTables(ti, parameters, PARAMETERS, t -> parameters, ti);
                    if (x != ti)
                        return x;

                    x = replaceTables(ti, attributes, ATTRIBUTES, t -> attributes, ti);
                    if (x != ti)
                        return x;
                }
                else if (q instanceof TableField<?, ?> tf) {
                    Field<?> x = replaceTables(tf.getTable(), routines, ROUTINES, t -> t.field(tf), tf);
                    if (x != tf)
                        return x;

                    x = replaceTables(tf.getTable(), parameters, PARAMETERS, t -> t.field(tf), tf);
                    if (x != tf)
                        return x;

                    x = replaceTables(tf.getTable(), attributes, ATTRIBUTES, t -> t.field(tf), tf);
                    if (x != tf)
                        return x;
                }

                return q;
            }));
        }));

        return ctx;
    }

    private Field<String> formatType(PgType t) {
        Field<String> f = field("format_type({0}, null)", VARCHAR, t.OID);
        return when(f.eq(inline("integer")), inline("int4")).else_(f);
    }

    @SuppressWarnings("unchecked")
    private <Q extends QueryPart> Q replaceTables(Table<?> t, Table<?> r, Table<?> e, Function<? super Table<?>, ? extends Q> ifTrue, Q ifFalse) {
        if (e.equals(t))
            return ifTrue.apply(r);

        if (t instanceof Aliasable<?> a) {
            Table<?> alias = (Table<?>) a.$aliased();

            if (e.equals(alias)) {
                Q q = ifTrue.apply(alias);

                if (q instanceof Table<?> qt) {
                    return (Q) qt.as(a.$alias());
                }
            }
        }

        return ifFalse;
    }

    @Override
    protected List<IndexDefinition> getIndexes0() throws SQLException {
        // We cannot use the PostgreSQL query as CockroachDB cannot correlate an
        // array aggregation subquery with the outer query (see super impl)
        // Using show index instead: https://www.cockroachlabs.com/docs/stable/show-index.html

        List<IndexDefinition> result = new ArrayList<>();

        for (SchemaDefinition schema : getSchemata()) {
            for (final TableDefinition table : getTables(schema)) {

                // [#16686] Exclude "table" that can't have indexes
                if (table.isTableValuedFunction())
                    continue;

                Map<Record, Result<Record>> indexes = create()
                        .fetch("show indexes from {0}", table.getQualifiedInputNamePart())
                        .intoGroups(
                            new String[] { "table_name", "index_name", "non_unique", "implicit" },
                            new String[] { "seq_in_index", "column_name", "direction" }
                        );

                indexLoop:
                for (Entry<Record, Result<Record>> index : indexes.entrySet()) {
                    Record key = index.getKey();

                    // Secondary indexes seem to implicitly contain the primary
                    // probably to automatically produce covering indexes.
                    // See: https://www.cockroachlabs.com/docs/stable/show-index.html
                    if (key.get("implicit", boolean.class))
                        continue indexLoop;

                    Result<Record> value = index.getValue().sortAsc("seq_in_index");

                    final String indexName = key.get("index_name", String.class);
                    final List<String> columns = value.getValues("column_name", String.class);
                    final List<String> directions = value.getValues("direction", String.class);

                    final boolean unique = !key.get("non_unique", boolean.class);

                    if (!getIncludeSystemIndexes() && indexName != null) {

                        // [#9601] FK indexes are named [table]_auto_index_[fk]
                        if (indexName.contains("_auto_index_"))
                            continue indexLoop;

                        // [#9601] The PK
                        if (table.getPrimaryKey() != null)
                            if (indexName.equals(table.getPrimaryKey().getInputName()))
                                continue indexLoop;

                        for (UniqueKeyDefinition uk : table.getUniqueKeys())
                            if (indexName.equals(uk.getInputName()))
                                continue indexLoop;
                    }

                    // [#6310] [#6620] Function-based indexes are not yet supported
                    // [#16237]        Alternatively, the column could be hidden or excluded
                    for (String column : columns)
                        if (table.getColumn(column) == null)
                            continue indexLoop;

                    result.add(new AbstractIndexDefinition(schema, indexName, table, unique) {
                        List<IndexColumnDefinition> indexColumns = new ArrayList<>();

                        {
                            for (int ordinal = 0; ordinal < columns.size(); ordinal++) {
                                ColumnDefinition column = table.getColumn(columns.get(ordinal));
                                SortOrder order = "DESC".equalsIgnoreCase(directions.get(ordinal)) ? SortOrder.DESC : SortOrder.ASC;

                                indexColumns.add(new DefaultIndexColumnDefinition(
                                    this,
                                    column,
                                    order,
                                    ordinal + 1
                                ));
                            }
                        }

                        @Override
                        protected List<IndexColumnDefinition> getIndexColumns0() {
                            return indexColumns;
                        }
                    });
                }
            }
        }

        return result;
    }

    @Override
    protected List<DomainDefinition> getDomains0() throws SQLException {
        return new ArrayList<>();
    }

    @Override
    protected List<TriggerDefinition> getTriggers0() throws SQLException {
        return new ArrayList<>();
    }

    @Override
    protected Condition nameconcatoid(Routines r1) {
        return PG_PROC.PRONAME.concat("_").concat(PG_PROC.OID).eq(r1.SPECIFIC_NAME);
    }

    @Override
    protected Condition columnCondition() {

        // The documentation claims this is "true" or "false", but actual data
        // suggests it's "YES" or "NO". See
        // https://www.cockroachlabs.com/docs/stable/information-schema.html#columns
        return !getIncludeInvisibleColumns()
            ? not(field("{0}.is_hidden", COLUMNS).isTrue())
            : noCondition();
    }

    @Override
    protected Condition columnHidden(Condition columnHidden) {
        return field("{0}.is_hidden", COLUMNS).isTrue();
    }

    @Override
    protected Field<String> columnDataTypeExpression(Field<String> dataTypeField) {
        return when(crdbSqlType().like(any(inline("INTERVAL%YEAR%"), inline("INTERVAL%MONTH%"))), inline("INTERVAL YEAR TO MONTH"))
            .when(crdbSqlType().like(any(inline("INTERVAL%DAY%"), inline("INTERVAL%HOUR%"), inline("INTERVAL%MINUTE%"), inline("INTERVAL%SECOND%"))), inline("INTERVAL DAY TO SECOND"))
            .else_(crdbSqlType());
    }

    @Override
    protected Condition columnDefaultFromIdentityExpression() {

        // [#18456] CockroachDB doesn't produce the same identifier case for REGCLASS
        return super.columnDefaultFromIdentityExpression()
            .or(COLUMNS.COLUMN_DEFAULT.eq(
                inline("nextval('").concat(COLUMNS.TABLE_NAME.concat(inline("_")).concat(COLUMNS.COLUMN_NAME)).concat(inline("_seq'::REGCLASS)"))
            ))
            .or(COLUMNS.COLUMN_DEFAULT.eq(
                inline("nextval('").concat(COLUMNS.TABLE_SCHEMA.concat(inline(".")).concat(COLUMNS.TABLE_NAME).concat(inline("_")).concat(COLUMNS.COLUMN_NAME)).concat(inline("_seq'::REGCLASS)"))
            ));
    }

    @Override
    protected Field<String> routineType(Routines r) {
        // [#15153] See https://github.com/cockroachdb/cockroach/blob/master/pkg/sql/vtable/information_schema.go
        //          There seems to be a bug in the INFORMATION_SCHEMA.ROUTINESS view's usage of array operators that
        //          reproduces consistently in our code generation run, leading to PROCEDURE typed routines being
        //          reported as FUNCTIONs
        return DSL.case_(
            field(
            select(PG_PROC.PROKIND)
            .from(PG_PROC)
            .where(PG_PROC.PRONAME.concat(inline("_")).concat(PG_PROC.OID).eq(r.SPECIFIC_NAME))
        )).when(inline("p"), inline("PROCEDURE"))
            .when(inline("f"), inline("FUNCTION"));
    }

    @Override
    protected Field<String> parameterMode(Parameters p) {
        // [#15153] See https://github.com/cockroachdb/cockroach/blob/master/pkg/sql/vtable/information_schema.go
        //          There seems to be a bug in the INFORMATION_SCHEMA.PARAMETERS view's usage of array operators that
        //          reproduces consistently in our code generation run, leading to OUT parameters being reported
        //          as IN parameters, but I can't find a way to create a minimal reproducer, so let's just work around
        //          the problem
        return DSL.case_(
            field(
            select(arrayGet(PG_PROC.PROARGMODES, p.ORDINAL_POSITION))
            .from(PG_PROC)
            .where(PG_PROC.PRONAME.concat(inline("_")).concat(PG_PROC.OID).eq(p.SPECIFIC_NAME))
        )).when(inline("i"), inline("IN"))
            .when(inline("o"), inline("OUT"))
            .when(inline("b"), inline("INOUT"))
            .when(inline("v"), inline("IN"))
            .when(inline("t"), inline("OUT"))
            .else_(inline("IN"));
    }

    @Override
    protected Field<String> columnUdtSchemaExpression(Field<String> udtSchemaField) {

        // [#14597] Depending on the CRDB version, this value contains a 2 or 3 part identifier:
        //          schema.type or catalog.schema.type.
        return regexpReplaceFirst(crdbSqlType(), inline("(.*\\.)?(.*?)\\..*"), inline("\\2"));
    }

    @Override
    protected Field<Integer> columnPrecisionExpression(Field<Integer> precisionField) {
        // [#9945] Workaround for missing feature:
        // https://github.com/cockroachdb/cockroach/issues/51286
        // [#9945] Use nullif() here to prevent crashing the server!
        // https://github.com/cockroachdb/cockroach/issues/51289
        return
            nvl(
                precisionField,
                cast(
                    nullif(
                        regexpReplaceFirst(
                            when(
                                upper(crdbSqlType()).in(inline("TIMESTAMP"), inline("TIMESTAMP(TZ)")),
                                crdbSqlType().concat(inline("(6)")))
                            .else_(crdbSqlType()),
                            inline(".*\\((\\d+)\\).*"),
                            inline("\\1")
                        ),
                        crdbSqlType()
                    ),
                    INTEGER
                )
            );
    }

    @Override
    protected boolean canUseRoutines() {
        return true;
    }

    @Override
    protected Field<String> serialColumnDefault(Field<String> serialColumnDefault) {

        // [#10399] Allow for translations of PostgreSQL serial column default expressions
        // [#12589] Let's be extra lenient as this seems to have changed in a recent CRDB version
        return inline("nextval('%'::%)");
    }

    @Override
    protected Field<String> generationExpression(Field<String> generationExpression) {
        return when(COLUMNS.IS_GENERATED.in(inline("YES"), inline("ALWAYS")), COLUMNS.GENERATION_EXPRESSION)
            .else_(inline(null, COLUMNS.GENERATION_EXPRESSION));
    }

    @Override
    protected Field<String> attgenerated(Field<String> attgenerated) {
        return attgenerated;
    }

    private Field<String> crdbSqlType() {
        return field("{0}.crdb_sql_type", VARCHAR, COLUMNS);
    }
}
