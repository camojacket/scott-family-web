/*
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit https://www.jooq.org/legal/licensing
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: https://www.jooq.org/legal/licensing
 */
package org.jooq.meta.db2;

import static org.jooq.impl.DSL.inline;
import static org.jooq.impl.DSL.noCondition;
import static org.jooq.impl.DSL.trim;
import static org.jooq.impl.DSL.when;
import static org.jooq.meta.db2.syscat.Tables.COLUMNS;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jooq.Condition;
import org.jooq.Record;
import org.jooq.TableOptions.TableType;
import org.jooq.meta.AbstractTableDefinition;
import org.jooq.meta.ColumnDefinition;
import org.jooq.meta.DataTypeDefinition;
import org.jooq.meta.DefaultColumnDefinition;
import org.jooq.meta.DefaultDataTypeDefinition;
import org.jooq.meta.SchemaDefinition;

import org.jetbrains.annotations.NotNull;

/**
 * DB2 table definition
 *
 * @author Espen Stromsnes
 */
public class DB2TableDefinition extends AbstractTableDefinition {

    public DB2TableDefinition(SchemaDefinition schema, String name, String comment) {
        super(schema, name, comment);
    }

    public DB2TableDefinition(SchemaDefinition schema, String name, String comment, TableType tableType, String source) {
        super(schema, name, comment, tableType, source);
    }

    @Override
    public List<ColumnDefinition> getElements0() throws SQLException {
        List<ColumnDefinition> result = new ArrayList<>();
        Condition visible = COLUMNS.HIDDEN.eq(inline(" "));
        boolean is10_1 = ((DB2Database) getDatabase()).is10_1();

        for (Record record : create().select(
                COLUMNS.COLNAME,
                COLUMNS.COLNO,
                COLUMNS.TYPENAME,
                when(COLUMNS.TYPENAME.eq(inline("TIMESTAMP")), COLUMNS.SCALE.coerce(COLUMNS.LENGTH))
                    .else_(COLUMNS.LENGTH).as(COLUMNS.LENGTH),
                when(COLUMNS.TYPENAME.eq(inline("TIMESTAMP")), inline((short) 0))
                    .else_(COLUMNS.SCALE).as(COLUMNS.SCALE),
                COLUMNS.IDENTITY,
                COLUMNS.NULLS,
                COLUMNS.DEFAULT,
                trim(COLUMNS.GENERATED).as(COLUMNS.GENERATED),
                COLUMNS.TEXT,
                (is10_1 ? COLUMNS.ROWBEGIN : inline("N")).as(COLUMNS.ROWBEGIN),
                (is10_1 ? COLUMNS.ROWEND : inline("N")).as(COLUMNS.ROWEND),
                (is10_1 ? COLUMNS.TRANSACTIONSTARTID : inline("N")).as(COLUMNS.TRANSACTIONSTARTID),
                COLUMNS.REMARKS,
                visible)
            .from(COLUMNS)
            .where(COLUMNS.TABSCHEMA.equal(getSchema().getName()))
            .and(COLUMNS.TABNAME.equal(getName()))
            .and(!getDatabase().getIncludeInvisibleColumns()
                ? visible
                : noCondition())
            .orderBy(COLUMNS.COLNO)
        ) {
            boolean generated = "A".equalsIgnoreCase(record.get(COLUMNS.GENERATED)) && record.get(COLUMNS.TEXT) != null;
            boolean identity = record.get(COLUMNS.IDENTITY, boolean.class);
            boolean rowBegin = record.get(COLUMNS.ROWBEGIN, boolean.class);
            boolean rowEnd = record.get(COLUMNS.ROWEND, boolean.class);
            boolean transactionStartId = record.get(COLUMNS.TRANSACTIONSTARTID, boolean.class);

            String g = rowBegin
                ? "ROW BEGIN"
                : rowEnd
                ? "ROW END"
                : transactionStartId
                ? "TRANSACTION START ID"
                : generated && !identity
                ? record.get(COLUMNS.TEXT).replaceAll("(?i:AS\\s*\\(\\s*(.*?)\\s*\\)\\s*)", "$1")
                : null;

            DefaultDataTypeDefinition type = new DefaultDataTypeDefinition(
                getDatabase(),
                getSchema(),
                record.get(COLUMNS.TYPENAME),
                record.get(COLUMNS.LENGTH),
                record.get(COLUMNS.LENGTH),
                record.get(COLUMNS.SCALE),
                record.get(COLUMNS.NULLS, boolean.class),
                generated || identity ? null : record.get(COLUMNS.DEFAULT)
            ).generatedAlwaysAs(g);

            if (getDatabase().getInvisibleColumnsAsHidden())
                type.hidden(!record.get(visible));

            result.add(new DefaultColumnDefinition(
            	getDatabase().getTable(getSchema(), getName()),
                record.get(COLUMNS.COLNAME),
                result.size() + 1,
                type,
                record.get(COLUMNS.IDENTITY, boolean.class),
                record.get(COLUMNS.REMARKS)
            ));
        }

        return result;
    }
}
