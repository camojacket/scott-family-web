/**
 * The jOOQ meta module.
 */
module org.jooq.meta {

    // Other jOOQ modules
    requires transitive org.jooq;

    // Nullability annotations for better Kotlin interop
    requires static org.jetbrains.annotations;

    // JAXB is used optionally for loading a variety of XML content, including
    // - Settings (org.jooq.conf)
    // - InformationSchema (org.jooq.util.xml.jaxb)
    requires static jakarta.xml.bind;

    exports org.jooq.meta;
    exports org.jooq.meta.cubrid;
    exports org.jooq.meta.derby;
    exports org.jooq.meta.firebird;
    exports org.jooq.meta.h2;
    exports org.jooq.meta.hsqldb;
    exports org.jooq.meta.ignite;
    exports org.jooq.meta.jaxb;
    exports org.jooq.meta.jdbc;
    exports org.jooq.meta.mariadb;
    exports org.jooq.meta.mysql;
    exports org.jooq.meta.postgres;
    exports org.jooq.meta.sqlite;
    exports org.jooq.meta.xml;
    exports org.jooq.meta.yugabytedb;


    exports org.jooq.meta.ase;
    exports org.jooq.meta.auroramysql;
    exports org.jooq.meta.aurorapostgres;
    exports org.jooq.meta.bigquery;
    exports org.jooq.meta.cockroachdb;
    exports org.jooq.meta.db2;
    exports org.jooq.meta.exasol;
    exports org.jooq.meta.hana;
    exports org.jooq.meta.informix;
    exports org.jooq.meta.ingres;
    exports org.jooq.meta.memsql;
    exports org.jooq.meta.oracle;
    exports org.jooq.meta.redshift;
    exports org.jooq.meta.snowflake;
    exports org.jooq.meta.sqldatawarehouse;
    exports org.jooq.meta.sqlserver;
    exports org.jooq.meta.sybase;
    exports org.jooq.meta.teradata;
    exports org.jooq.meta.vertica;


}
